import React from 'react';
import { motion } from 'framer-motion';
import { Mail, MapPin, Phone } from 'lucide-react';

const contactDetails = [
  {
    icon: Mail,
    label: 'Email',
    value: 'contact@flatforflip.com',
    link: 'mailto:contact@flatforflip.com'
  },
  {
    icon: Phone,
    label: 'Phone',
    value: '+1 (555) 123-4567',
    link: 'tel:+15551234567'
  },
  {
    icon: MapPin,
    label: 'Address',
    value: '123 Blockchain Street, Crypto City, CC 12345',
    link: 'https://maps.google.com'
  }
];

export const ContactInfo: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      className="space-y-8"
    >
      {contactDetails.map((detail, index) => {
        const Icon = detail.icon;
        return (
          <motion.a
            key={detail.label}
            href={detail.link}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="flex items-start gap-4 p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
          >
            <div className="p-2 rounded-lg bg-neon-green/20 text-neon-green">
              <Icon size={24} />
            </div>
            <div>
              <h3 className="font-medium mb-1">{detail.label}</h3>
              <p className="text-gray-400">{detail.value}</p>
            </div>
          </motion.a>
        );
      })}
    </motion.div>
  );
};