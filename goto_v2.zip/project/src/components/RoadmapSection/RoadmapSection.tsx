import React from 'react';
import { motion } from 'framer-motion';
import { CustomRoadmap } from './CustomRoadmap/CustomRoadmap';
import { SquaresGroup } from '../DecorativeSquares/SquaresGroup';

export const RoadmapSection: React.FC = () => {
  return (
    <section className="py-12 md:py-16 px-4 relative" id="roadmap">
      {/* Large decorative squares */}
      <SquaresGroup
        className="hidden md:block right-[-120px] top-1/3 z-10"
        rotate={-15}
        scale={2.2}
      />

      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8 md:mb-12">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="inline-flex justify-center items-center px-[15px] py-[5px] w-[155px] h-[34px] rounded-[12px] mb-4 md:mb-6"
            style={{
              background:
                'linear-gradient(0deg, rgba(0, 0, 0, 0.06), rgba(0, 0, 0, 0.06)), linear-gradient(224.83deg, rgba(255, 255, 255, 0.13) -7.89%, rgba(255, 255, 255, 0.04) 105.6%)',
              backdropFilter: 'blur(7.3px)',
            }}
          >
            <span className="font-inter font-normal text-[14px] leading-[17px] text-[#A2A2A2]">
              What is our mission
            </span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="font-inter font-semibold text-[55px] leading-[67px] text-center text-white mb-4 md:mb-6"
          >
            Roadmap
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="font-['Eloquia_Text'] font-light text-[15px] leading-[17.82px] text-center text-[#9B9B9B] max-w-2xl mx-auto mb-8 md:mb-12"
          >
            Our mission is to create a seamless bridge between the traditional
            real estate market and the digital world, incorporating blockchain
            and Web 3.0 technologies. We aim to generate lucrative investment
            opportunities for our community members, utilizing the experience
            and expertise of both traditional real estate investors and digital
            asset investors looking to diversify their portfolios
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="relative w-full"
          >
            <CustomRoadmap />
          </motion.div>
        </div>
      </div>
    </section>
  );
};
