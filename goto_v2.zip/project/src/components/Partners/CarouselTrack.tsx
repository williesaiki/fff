import React from 'react';
import { motion } from 'framer-motion';
import { PartnerImage } from './PartnerImage';

interface CarouselTrackProps {
  images: string[];
  direction: 'left' | 'right';
}

export const CarouselTrack: React.FC<CarouselTrackProps> = ({ images, direction }) => {
  const duration = 30;
  const trackVariants = {
    animate: {
      x: direction === 'left' ? [0, -1920] : [-1920, 0],
      transition: {
        x: {
          repeat: Infinity,
          repeatType: "loop",
          duration,
          ease: "linear",
        },
      },
    },
  };

  return (
    <div className="relative overflow-hidden my-4">
      <motion.div
        className="flex gap-8"
        variants={trackVariants}
        animate="animate"
      >
        {/* Double the images to create seamless loop */}
        {[...images, ...images].map((src, index) => (
          <PartnerImage key={`${src}-${index}`} src={src} />
        ))}
      </motion.div>
    </div>
  );
};