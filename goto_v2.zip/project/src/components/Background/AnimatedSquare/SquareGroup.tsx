import React from 'react';
import { motion } from 'framer-motion';

interface SquareGroupProps {
  left: number;
  top: number;
  rotation?: number;
  delay?: number;
}

export const SquareGroup: React.FC<SquareGroupProps> = ({ 
  left, 
  top, 
  rotation = 16.98,
  delay = 0
}) => {
  return (
    <motion.div 
      className="absolute"
      style={{ left, top }}
      initial={{ y: 0, rotate: 0 }}
      animate={{
        y: [-10, 0, -10],
        rotate: [-5, 0, -5],
      }}
      transition={{
        duration: 6,
        repeat: Infinity,
        ease: "easeInOut",
        delay,
        times: [0, 0.5, 1]
      }}
    >
      {/* Background lighter square */}
      <div
        className="absolute"
        style={{
          width: 5162,
          height: 5162,
          background: '#C4FC33',
          borderRadius: 80,
          boxShadow: '0px 0px 565px rgba(196, 252, 51, 0.19)',
          transform: `rotate(${rotation}deg)`,
          left: 3430,
          top: 2165,
        }}
      />

      {/* Blurred overlay square */}
      <div
        className="absolute backdrop-blur-[45.5px]"
        style={{
          width: 4800,
          height: 4900,
          left: 5205,
          top: 3243,
          background: 'linear-gradient(0deg, rgba(0, 0, 0, 0.06), rgba(0, 0, 0, 0.06)), linear-gradient(224.83deg, rgba(255, 255, 255, 0.13) -7.89%, rgba(255, 255, 255, 0.04) 105.6%)',
          borderRadius: 80,
          transform: 'rotate(106.98deg)',
        }}
      />
    </motion.div>
  );
};