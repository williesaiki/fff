import { motion } from 'framer-motion';
import React from 'react';

interface FloatingSquareProps {
  className?: string;
  delay?: number;
}

export const FloatingSquare: React.FC<FloatingSquareProps> = ({ className = '', delay = 0 }) => {
  return (
    <motion.div
      className={`w-16 h-16 bg-neon-green/20 rounded-lg absolute ${className}`}
      initial={{ opacity: 0, scale: 0 }}
      animate={{ 
        opacity: [0.5, 0.8, 0.5],
        scale: [1, 1.2, 1],
        rotate: [0, 10, -10, 0]
      }}
      transition={{
        duration: 6,
        delay,
        repeat: Infinity,
        ease: "easeInOut"
      }}
    />
  );
};