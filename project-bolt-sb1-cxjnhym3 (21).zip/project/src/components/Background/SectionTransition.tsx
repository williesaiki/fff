import React from 'react';

interface SectionTransitionProps {
  position: 'top' | 'bottom';
  height?: string;
  className?: string;
}

export const SectionTransition: React.FC<SectionTransitionProps> = ({
  position,
  height = '150px',
  className = ''
}) => {
  return (
    <div 
      className={`absolute left-0 right-0 pointer-events-none ${
        position === 'top' ? 'top-0' : 'bottom-0'
      } ${className}`}
      style={{
        height,
        background: position === 'top'
          ? 'linear-gradient(180deg, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0) 100%)'
          : 'linear-gradient(0deg, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0) 100%)',
      }}
    />
  );
};