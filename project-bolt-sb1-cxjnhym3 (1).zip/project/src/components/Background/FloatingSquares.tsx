import React from 'react';
import { FloatingSquare } from './FloatingSquare';
import { getRandomNumber } from './utils/random';

// Generate random positions and movements for squares
const squares = Array.from({ length: 8 }, () => ({
  x: getRandomNumber(-200, 200),
  y: getRandomNumber(-180, 180),
  size: getRandomNumber(60, 120),
  delay: getRandomNumber(0, 10),
  left: `${getRandomNumber(20, 80)}%`,
  top: `${getRandomNumber(20, 80)}%`,
}));

export const FloatingSquares: React.FC = () => {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {squares.map((square, index) => (
        <div
          key={index}
          className="absolute"
          style={{
            left: square.left,
            top: square.top,
          }}
        >
          <FloatingSquare
            size={square.size}
            delay={square.delay}
            x={square.x}
            y={square.y}
          />
        </div>
      ))}
    </div>
  );
};