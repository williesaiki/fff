import React from 'react';
import { motion } from 'framer-motion';

interface MobileMenuButtonProps {
  isOpen: boolean;
  onClick: () => void;
}

export const MobileMenuButton: React.FC<MobileMenuButtonProps> = ({ isOpen, onClick }) => {
  return (
    <button 
      onClick={onClick}
      className="p-2"
      aria-label={isOpen ? 'Close menu' : 'Open menu'}
    >
      <motion.img
        src={isOpen ? '/Vector.svg' : '/Vector_zamkniete.svg'}
        alt={isOpen ? 'Close menu' : 'Open menu'}
        className="w-8 h-8" // Increased from w-6 h-6 to w-8 h-8
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.2 }}
      />
    </button>
  );
};