import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const menuItems = [
  { href: '#about', label: 'About' },
  { href: '#team', label: 'Team' },
  { href: '#token', label: 'Token' },
  { href: '#roadmap', label: 'Roadmap' },
  { href: '#faq', label: 'FAQ' },
  { href: '#docs', label: 'Docs' }
];

export const MobileMenu: React.FC<MobileMenuProps> = ({ isOpen, onClose }) => {
  const handleClick = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      onClose();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="absolute top-full left-0 right-0 bg-black/95 backdrop-blur-lg border-t border-white/10 py-4 px-4"
        >
          <nav className="flex flex-col space-y-4">
            {menuItems.map(({ href, label }) => (
              <button
                key={href}
                onClick={() => handleClick(href)}
                className="text-left py-2 text-gray-300 hover:text-neon-green transition-colors"
              >
                {label}
              </button>
            ))}
            <button className="bg-neon-green text-black px-6 py-2 rounded-lg font-semibold hover:bg-neon-green/90 transition-colors">
              Launch App
            </button>
          </nav>
        </motion.div>
      )}
    </AnimatePresence>
  );
};