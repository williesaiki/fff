import React from 'react';
import { navLinks } from './navConfig';

export const NavLinks: React.FC = () => {
  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {navLinks.map(({ href, label }) => (
        <a
          key={href}
          href={href}
          onClick={(e) => scrollToSection(e, href)}
          className="text-gray-300 hover:text-neon-green transition-colors text-sm md:text-base"
        >
          {label}
        </a>
      ))}
    </>
  );
};