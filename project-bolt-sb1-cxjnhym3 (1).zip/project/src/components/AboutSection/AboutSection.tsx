import React from 'react';
import { AboutHeading } from './AboutHeading';
import { FeatureList } from './FeatureList';

const features = [
  {
    title: "Real estate-backed security",
    description: "We stand out by ensuring stability and value through real estate assets."
  },
  {
    title: "Tokenomics Strategy",
    description: "Our tokenomics focus on sustainable growth, encouraging users to participate in real estate projects while building the token's value."
  },
  {
    title: "Security and Auditing",
    description: "Every project undergoes legal, financial, and economic analysis before being presented to the community."
  },
  {
    title: "Innovation in Real Estate Market",
    description: "The ability to gain exposure to the real estate market regardless of your country of residence or the location of the property."
  }
];

export const AboutSection: React.FC = () => {
  return (
    <section className="py-8 px-4" id="about">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-6">
          <AboutHeading />
          <FeatureList features={features} />
        </div>
      </div>
    </section>
  );
};