import React from 'react';
import { motion } from 'framer-motion';

export const RoadmapSection: React.FC = () => {
  return (
    <section className="py-12 md:py-16 px-4 relative">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8 md:mb-12">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="inline-block px-4 py-2 rounded-full bg-zinc-900 text-xs sm:text-sm mb-4 md:mb-6"
          >
            What is our mission
          </motion.div>
          
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-3xl sm:text-4xl md:text-4xl font-bold mb-4 md:mb-6"
          >
            Roadmap
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="text-gray-400/80 max-w-2xl mx-auto text-sm sm:text-base md:text-base mb-8 md:mb-12"
          >
            To offer crypto investors a simple and accessible way to gain exposure to the real estate market while
            providing real estate developers with a new source of financing secured by their properties.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="relative w-full overflow-hidden mt-12"
          >
            <img
              src="/Roadmap.svg"
              alt="Roadmap visualization"
              className="w-full max-w-[1200px] mx-auto"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
};