import React from 'react';
import { motion } from 'framer-motion';

export const OpeningImage: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      transition={{ duration: 1 }}
      className="relative w-full max-w-[1100px] mx-auto px-4" // Reduced from 1200px to 1100px
    >
      <img
        src="/We are opening the real estate market to everyone.svg"
        alt="We are opening the real estate market to everyone"
        className="w-full h-auto"
        loading="eager"
      />
    </motion.div>
  );
};