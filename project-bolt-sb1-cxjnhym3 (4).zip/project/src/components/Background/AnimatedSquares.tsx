import React from 'react';
import { Square } from './Square';

const squares = [
  { size: 400, x: -20, y: -15, delay: 0, duration: 25 },
  { size: 500, x: 25, y: 20, delay: 2, duration: 28 },
  { size: 450, x: 15, y: -25, delay: 4, duration: 30 },
  { size: 550, x: -25, y: 15, delay: 6, duration: 26 },
  { size: 480, x: 20, y: -20, delay: 8, duration: 29 },
  { size: 520, x: -15, y: 25, delay: 10, duration: 27 }
];

export const AnimatedSquares: React.FC = () => {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none">
      {squares.map((square, index) => (
        <Square key={index} {...square} />
      ))}
    </div>
  );
};