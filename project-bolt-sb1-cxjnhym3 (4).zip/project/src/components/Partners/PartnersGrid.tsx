import React from 'react';
import { PartnerLogo } from './PartnerLogo';

const partners = [
  { src: '/partnerzy/1.png', alt: 'Samana Group' },
  { src: '/partnerzy/2.png', alt: 'Reliance Pro' },
  { src: '/partnerzy/3.png', alt: 'Invest Cuffs' },
  { src: '/partnerzy/4.png', alt: 'Comparic' },
  { src: '/partnerzy/5.png', alt: 'Reach4' },
  { src: '/partnerzy/6.png', alt: 'Cashify' },
  { src: '/partnerzy/7.png', alt: 'Biznesowa' }
];

export const PartnersGrid: React.FC = () => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8 max-w-4xl mx-auto">
      {partners.map((partner, index) => (
        <PartnerLogo 
          key={index}
          {...partner}
          className={index === partners.length - 1 ? 'col-span-2 md:col-span-1' : ''}
        />
      ))}
    </div>
  );
};