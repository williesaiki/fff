import React from 'react';
import { motion } from 'framer-motion';
import { TeamMember } from './TeamMember';

const teamMembers = [
  {
    name: "Dariusz Barski",
    role: "Founder",
    imageUrl: "/1img_flat_for_flip.jpg",
    linkedin: "https://linkedin.com",
    twitter: "https://twitter.com"
  },
  {
    name: "Marcin Bochenek",
    role: "Founder",
    imageUrl: "/2img_flat_for_flip.jpg",
    linkedin: "https://linkedin.com",
    twitter: "https://twitter.com"
  },
  {
    name: "Jan Sczepan",
    role: "Head of Operations",
    imageUrl: "/3img_flat_for_flip.jpg",
    linkedin: "https://linkedin.com",
    twitter: "https://twitter.com"
  },
  {
    name: "Emma Williams",
    role: "Chief Marketing Officer",
    imageUrl: "/4img_flat_for_flip.jpg",
    linkedin: "https://linkedin.com",
    twitter: "https://twitter.com"
  }
];

export const TeamSection: React.FC = () => {
  return (
    <section className="py-16 px-4" id="team">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <div className="inline-flex flex-row justify-center items-center px-[15px] py-[5px] gap-[10px] w-[130px] h-[34px] rounded-[12px] backdrop-blur-[7.3px]"
            style={{
              background: 'linear-gradient(0deg, rgba(0, 0, 0, 0.06), rgba(0, 0, 0, 0.06)), linear-gradient(224.83deg, rgba(255, 255, 255, 0.13) -7.89%, rgba(255, 255, 255, 0.04) 105.6%)'
            }}
          >
            <span className="font-inter font-normal text-[14px] leading-[17px] text-[#A2A2A2]">
              Who's behind?
            </span>
          </div>
          
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="font-inter font-semibold text-[55px] leading-[67px] text-center text-white mb-4 mt-6"
          >
            Our Team
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="font-['Eloquia_Text'] font-light text-[15px] leading-[17.82px] text-center text-[#9B9B9B] max-w-2xl mx-auto px-4"
          >
            Meet our dedicated team of professionals working to revolutionize real estate investment through blockchain technology.
          </motion.p>
        </div>

        <div className="flex flex-wrap justify-center gap-8 md:gap-[45px]">
          {teamMembers.map((member, index) => (
            <TeamMember
              key={member.name}
              {...member}
              index={index}
            />
          ))}
        </div>
      </div>
    </section>
  );
}