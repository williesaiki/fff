import React from 'react';

export const FAQBackground: React.FC = () => {
  return (
    <div 
      className="absolute inset-0 w-full h-full -z-10"
      aria-hidden="true"
    >
      {/* Background blur effect */}
      <div 
        className="absolute inset-0 bg-[#D9D9D9] opacity-[0.03]"
        style={{ 
          filter: 'blur(71.25px)',
        }} 
      />
      
      {/* City image */}
      <img 
        src="/FAQ City Background.svg"
        alt=""
        className="absolute inset-0 w-full h-full object-cover opacity-[0.03]"
      />
    </div>
  );
};