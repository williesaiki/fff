import React from 'react';
import { motion } from 'framer-motion';

interface TokenFeatureProps {
  icon: string;
  title: string;
  description: string;
  index: number;
}

export const TokenFeature: React.FC<TokenFeatureProps> = ({
  icon,
  title,
  description,
  index
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: index * 0.2 }}
      className="group text-center"
    >
      <div className="flex justify-center mb-4">
        <div className="relative w-[400px] h-[291px]">
          <img 
            src={icon} 
            alt={title}
            className="w-full h-full transition-all duration-300"
            style={{
              filter: "brightness(0) saturate(100%) invert(100%) sepia(0%) saturate(2%) hue-rotate(137deg) brightness(111%) contrast(101%)"
            }}
          />
          <div 
            className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
            style={{
              backgroundImage: `url(${icon})`,
              backgroundSize: 'contain',
              backgroundPosition: 'center',
              backgroundRepeat: 'no-repeat',
              filter: "brightness(0) saturate(100%) invert(88%) sepia(29%) saturate(1011%) hue-rotate(48deg) brightness(106%) contrast(106%)"
            }}
          />
        </div>
      </div>
      
      <h3 className="text-2xl font-bold mb-2">{title}</h3>
      <p className="text-[#9B9B9B] text-base">{description}</p>
    </motion.div>
  );
};