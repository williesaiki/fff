import React from 'react';
import { motion } from 'framer-motion';
import { SquareProps } from './types';

export const Square: React.FC<SquareProps> = ({
  size = 51.62,
  rotation = 16.98,
  left,
  top,
  delay = 0
}) => {
  return (
    <motion.div
      className="absolute"
      style={{
        width: size,
        height: size,
        left,
        top,
        transform: `rotate(${rotation}deg)`
      }}
      initial={{ scale: 0.95, opacity: 0.8 }}
      animate={{
        scale: [0.95, 1.05, 0.95],
        opacity: [0.8, 1, 0.8],
        rotate: [rotation, rotation + 5, rotation]
      }}
      transition={{
        duration: 6,
        repeat: Infinity,
        ease: "easeInOut",
        delay
      }}
    >
      <div
        className="w-full h-full bg-neon-green rounded-lg"
        style={{
          boxShadow: '0px 0px 56.5px rgba(196, 252, 51, 0.19)'
        }}
      />
    </motion.div>
  );
};