import React from 'react';
import { motion } from 'framer-motion';
import { Logo } from './Logo';

const navLinks = [
  { href: '#about', label: 'About' },
  { href: '#team', label: 'Team' },
  { href: '#token', label: 'Token' },
  { href: '#roadmap', label: 'Roadmap' },
  { href: '#faq', label: 'FAQ' },
  { href: '#docs', label: 'Docs' }
];

export const Navbar: React.FC = () => {
  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="fixed w-full top-0 z-50 bg-black/50 backdrop-blur-lg"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-2">
            <Logo />
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map(({ href, label }) => (
              <a
                key={href}
                href={href}
                onClick={(e) => scrollToSection(e, href)}
                className="text-gray-300 hover:text-neon-green transition-colors"
              >
                {label}
              </a>
            ))}
          </div>

          <button className="bg-neon-green text-black px-6 py-2 rounded-lg font-semibold hover:bg-neon-green/90 transition-colors">
            Launch App
          </button>
        </div>
      </div>
    </motion.nav>
  );
};