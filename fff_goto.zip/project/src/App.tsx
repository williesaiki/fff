import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MainBackground } from './components/Background/MainBackground';
import { GradientGrid } from './components/Background/GradientGrid';
import { GreenSquares } from './components/Background/GreenSquares';
import { Navbar } from './components/Navbar/Navbar';
import { Partners } from './components/Partners';
import { AboutSection } from './components/AboutSection/AboutSection';
import { TeamSection } from './components/TeamSection/TeamSection';
import { TokenSection } from './components/TokenSection/TokenSection';
import { RoadmapSection } from './components/RoadmapSection/RoadmapSection';
import { FAQSection } from './components/FAQSection/FAQSection';
import { LinksSection } from './components/LinksSection/LinksSection';
import { Footer } from './components/Footer';
import { GridPattern } from './components/Background/GridPattern';
import { SectionBackground } from './components/Background/SectionBackground';
import { ComingSoon } from './pages/ComingSoon';
import { HeroButton } from './components/HeroSection/HeroButton';

const HomePage = () => (
  <div className="min-h-screen bg-black text-white overflow-hidden">
    <MainBackground />
    <GradientGrid />
    <GreenSquares />
    
    <div className="relative z-10">
      <Navbar />
      
      <main className="relative pt-52 md:pt-64 pb-4 px-4">
        <GridPattern opacity={0.25} />
        <div className="max-w-7xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8 md:space-y-10 mb-16 md:mb-20"
          >
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold leading-tight">
              <span className="text-neon-green">Real Estate</span> Yield For<br />
              Everyone With <span className="text-neon-green">Crypto</span>
            </h1>
            
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.7 }}
              transition={{ delay: 0.4 }}
              className="max-w-2xl mx-auto text-gray-400 text-lg sm:text-xl"
            >
              Transform your crypto investments into real estate opportunities. 
              Join the future of property investment with our innovative platform.
            </motion.p>

            <HeroButton />
          </motion.div>

          <div className="mb-32">
            <Partners />
          </div>
        </div>
      </main>

      <div className="relative">
        <SectionBackground />
        <GridPattern opacity={0.08} />
        
        <div id="about">
          <AboutSection />
        </div>
        
        <div id="team">
          <TeamSection />
        </div>
        
        <div id="token">
          <TokenSection />
        </div>
        
        <div id="roadmap">
          <RoadmapSection />
        </div>
        
        <div id="faq">
          <FAQSection />
        </div>
        
        <div id="docs">
          <LinksSection />
        </div>

        <Footer />
      </div>
    </div>
  </div>
);

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/coming-soon" element={<ComingSoon />} />
      </Routes>
    </Router>
  );
}