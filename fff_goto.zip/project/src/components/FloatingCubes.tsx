import React from 'react';
import { motion } from 'framer-motion';

interface CubeProps {
  className?: string;
  delay?: number;
  size?: string;
  blur?: string;
}

const Cube: React.FC<CubeProps> = ({ 
  className = '', 
  delay = 0, 
  size = 'w-16 h-16',
  blur = 'blur-lg'
}) => {
  return (
    <motion.div
      className={`absolute ${size} ${blur} bg-neon-green/20 rounded-lg ${className}`}
      initial={{ opacity: 0, scale: 0 }}
      animate={{ 
        opacity: [0.3, 0.6, 0.3],
        scale: [1, 1.2, 1],
        rotate: [0, 10, -10, 0]
      }}
      transition={{
        duration: 6,
        delay,
        repeat: Infinity,
        ease: "easeInOut"
      }}
    />
  );
};

export const FloatingCubes: React.FC = () => {
  return (
    <>
      <Cube className="top-20 left-20" delay={0} />
      <Cube className="top-40 right-32" delay={1} size="w-24 h-24" />
      <Cube className="bottom-20 left-1/4" delay={2} size="w-20 h-20" blur="blur-xl" />
      <Cube className="top-60 right-1/4" delay={3} />
      <Cube className="bottom-40 right-20" delay={4} size="w-32 h-32" blur="blur-2xl" />
      <Cube className="top-32 left-1/3" delay={5} size="w-16 h-16" />
    </>
  );
};