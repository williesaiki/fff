import React from 'react';
import { motion } from 'framer-motion';
import { ArrowUp } from 'lucide-react';

export const BackToTop: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <motion.button
      onClick={scrollToTop}
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      className="flex items-center gap-2 mx-auto px-6 py-2 rounded-lg text-gray-400 hover:text-neon-green transition-colors group"
    >
      <span>Back to top</span>
      <ArrowUp size={20} className="group-hover:-translate-y-1 transition-transform" />
    </motion.button>
  );
};