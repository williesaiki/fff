import React from 'react';

export const LogoImage: React.FC = () => {
  return (
    <img
      src="/LOGO.svg"
      alt="FlatForFlip"
      className="h-8 w-auto"
      draggable={false}
    />
  );
};