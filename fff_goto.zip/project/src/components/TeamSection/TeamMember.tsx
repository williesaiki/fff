import React from 'react';
import { motion } from 'framer-motion';

interface TeamMemberProps {
  name: string;
  role: string;
  imageUrl: string;
  linkedin?: string;
  twitter?: string;
  index: number;
  objectPosition?: string;
}

export const TeamMember: React.FC<TeamMemberProps> = ({
  name,
  role,
  imageUrl,
  linkedin,
  twitter,
  index,
  objectPosition = 'center 30%',
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: index * 0.2 }}
      className="relative group w-[228px]"
    >
      <div className="rounded-lg overflow-hidden bg-black border border-transparent group-hover:border-neon-green transition-colors duration-300">
        <div className="aspect-square relative">
          <img
            src={imageUrl}
            alt={name}
            width={228}
            height={228}
            className="w-full h-full object-cover"
            style={{ objectPosition }}
            loading={index === 0 ? 'eager' : 'lazy'}
          />
        </div>
        <div className="p-3">
          <h3 className="text-lg font-semibold">{name}</h3>
          <p className="text-gray-400 text-xs font-eloquia">{role}</p>
          <div className="flex justify-center gap-4 mt-2">
            {linkedin && (
              <a
                href={linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="w-4 h-4 text-gray-400 hover:text-neon-green transition-colors"
              >
                <img
                  src="/linkedin.svg"
                  alt="LinkedIn"
                  className="w-full h-full opacity-70 hover:opacity-100 transition-opacity"
                />
              </a>
            )}
            {twitter && (
              <a
                href={twitter}
                target="_blank"
                rel="noopener noreferrer"
                className="w-4 h-4 text-gray-400 hover:text-neon-green transition-colors"
              >
                <img
                  src="/x.svg"
                  alt="X (Twitter)"
                  className="w-full h-full opacity-70 hover:opacity-100 transition-opacity"
                />
              </a>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
};
