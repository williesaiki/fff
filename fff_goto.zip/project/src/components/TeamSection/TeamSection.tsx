import React from 'react';
import { motion } from 'framer-motion';

const teamMembers = [
  {
    name: 'Dariusz Barski',
    role: 'Founder',
    imageUrl: '/1img_flat_for_flip.jpg',
    linkedin: 'https://www.linkedin.com/in/dariusz-barski-b95a1456/',
    objectPosition: 'center 35%',
  },
  {
    name: 'Marcin Bochenek',
    role: 'Founder',
    imageUrl: '/2img_flat_for_flip.jpg',
    linkedin: 'https://www.linkedin.com/in/marcin-bochenek-5a8079130/',
    objectPosition: 'center 35%',
  },
  {
    name: 'Przemysław Prończuk',
    role: 'Chief Marketing Officer',
    imageUrl: '/4img_flat_for_flip.jpg',
    linkedin: 'https://www.linkedin.com/in/przemekpronczuk/',
    objectPosition: 'center 35%',
  },
  {
    name: 'Jan Sczepan',
    role: 'Chief Technology Officer',
    imageUrl: '/3img_flat_for_flip.jpg',
    linkedin: 'https://www.linkedin.com/in/jan-szczepan-216550258/',
    objectPosition: 'center 40%',
  },
];

export const TeamSection: React.FC = () => {
  return (
    <section className="py-16 px-4" id="team">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <div
            className="inline-flex flex-row justify-center items-center px-[15px] py-[5px] gap-[10px] w-[130px] h-[34px] rounded-[12px] backdrop-blur-[7.3px]"
            style={{
              background:
                'linear-gradient(0deg, rgba(0, 0, 0, 0.06), rgba(0, 0, 0, 0.06)), linear-gradient(224.83deg, rgba(255, 255, 255, 0.13) -7.89%, rgba(255, 255, 255, 0.04) 105.6%)',
            }}
          >
            <span className="font-inter font-normal text-[14px] leading-[17px] text-[#A2A2A2]">
              Who's behind?
            </span>
          </div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="font-inter font-semibold text-[55px] leading-[67px] text-center text-[#C4FC33] mb-4 mt-6"
          >
            Our Team
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="font-eloquia font-light text-[15px] leading-[17.82px] text-center text-[#9B9B9B] max-w-2xl mx-auto px-4"
          >
            Meet our dedicated team of professionals working to revolutionize
            real estate investment through blockchain technology.
          </motion.p>
        </div>

        <div className="flex flex-wrap justify-center gap-8 md:gap-[45px]">
          {teamMembers.map((member, index) => (
            <div
              key={member.name}
              className="text-center group relative w-[228px]"
            >
              <div className="rounded-lg overflow-hidden bg-black border border-transparent group-hover:border-neon-green transition-colors duration-300">
                <div className="aspect-square relative">
                  <img
                    src={member.imageUrl}
                    alt={member.name}
                    width={228}
                    height={228}
                    className="w-full h-full object-cover"
                    style={{ objectPosition: member.objectPosition }}
                    loading={index === 0 ? 'eager' : 'lazy'}
                  />
                </div>
                <div className="p-3">
                  <h3 className="text-lg font-semibold text-white">
                    {member.name}
                  </h3>
                  <p className="text-[#C4FC33] text-xs font-eloquia">
                    {member.role}
                  </p>
                  <div className="flex justify-center gap-4 mt-2">
                    {member.linkedin && (
                      <a
                        href={member.linkedin}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-4 h-4 text-gray-400 hover:text-neon-green transition-colors"
                      >
                        <img
                          src="/linkedin.svg"
                          alt="LinkedIn"
                          className="w-full h-full opacity-70 hover:opacity-100 transition-opacity"
                        />
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
