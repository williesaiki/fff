import React from 'react';

export const FooterText: React.FC = () => {
  return (
    <div className="text-center space-y-2">
      <p className="text-white/90 font-medium text-lg">FLATFORFLIP</p>
      <a
        href="mailto:contact@flatforflip.io"
        className="text-neon-green hover:text-neon-green/80 transition-colors inline-block"
      >
        contact@flatforflip.io
      </a>
    </div>
  );
};
