import React from 'react';

interface TokenIconProps {
  src: string;
  alt: string;
  isMiddle?: boolean;
}

export const TokenIcon: React.FC<TokenIconProps> = ({ src, alt, isMiddle }) => {
  return (
    <img
      src={src}
      alt={alt}
      className={`w-32 h-32 transition-all duration-300 ${
        isMiddle
          ? 'brightness-100'
          : 'group-hover:brightness-[2] group-hover:filter-neon-green'
      }`}
    />
  );
};
