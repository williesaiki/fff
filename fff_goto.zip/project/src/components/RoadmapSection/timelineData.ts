import { TimelineItemType } from './types';

export const timelineData: TimelineItemType[] = [
  {
    type: 'year',
    content: '2023/2024'
  },
  {
    type: 'item',
    content: 'Building a Web 2.0 community around the project.'
  },
  {
    type: 'item',
    content: 'Building community and reach on social media (Web 3.0)'
  },
  {
    type: 'item',
    content: 'Organizing events for the community'
  },
  {
    type: 'item',
    content: 'Internal sales of real estate with a total value of 25 million USD'
  },
  {
    type: 'item',
    content: 'Real estate sold through the Flat For Flip community valued at 25 million USD. Generated over 500,000 USD in commissions for community members.'
  },
  {
    type: 'item',
    content: 'Development of a residential estate conducted by a project in Europe'
  },
  {
    type: 'year',
    content: '2025'
  }
];