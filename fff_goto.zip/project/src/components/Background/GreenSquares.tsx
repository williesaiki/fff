import React from 'react';
import { Square } from './Square';

export const GreenSquares: React.FC = () => {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {/* Top squares */}
      <Square
        className="left-[150px] top-[232px]"
        size={45}
        shadow
        hideOnMobile
        delay={0}
      />

      <Square
        className="right-[150px] top-[218px]"
        size={45}
        shadow
        rotate={90}
        hideOnMobile
        delay={1}
      />

      {/* Middle squares */}
      <Square
        className="left-[200px] top-[481px]"
        size={30}
        shadow
        rotate={45}
        delay={2}
      />

      <Square
        className="right-[200px] top-[481px]"
        size={30}
        shadow
        rotate={45}
        delay={1.5}
      />

      {/* Bottom squares */}
      <Square
        className="left-[196px] top-[800px]"
        size={35}
        shadow
        rotate={17}
        delay={0.5}
      />

      <Square
        className="right-[155px] top-[800px]"
        size={35}
        shadow
        rotate={17}
        delay={2.5}
      />

      <Square
        className="left-[146px] top-[1200px]"
        size={30}
        shadow
        rotate={5}
        delay={1.8}
      />

      <Square
        className="right-[116px] top-[1200px]"
        size={30}
        shadow
        rotate={5}
        delay={0.8}
      />
    </div>
  );
};