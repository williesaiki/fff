import React from 'react';
import { motion } from 'framer-motion';

export const MainBackground: React.FC = () => {
  return (
    <div className="fixed inset-0 w-full h-full overflow-hidden pointer-events-none">
      {/* Main black blur at the top */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="absolute w-[1934px] h-[509px] left-[-247px] top-[-1px] bg-black blur-[142.4px]"
      />

      {/* Gray overlay */}
      <div className="absolute w-[2418px] h-[1332px] left-1/2 top-[-269px] -translate-x-1/2 bg-[rgba(149,149,149,0.02)]" />

      {/* Large gray blur */}
      <div className="absolute w-[3006px] h-[764px] left-[-817px] top-[-295px] bg-[rgba(211,211,211,0.09)] blur-[250px]" />

      {/* About section background */}
      <div className="absolute w-[1919px] h-[940px] left-[-239px] top-[1170px] bg-black blur-[125px]" />

      {/* Team section background */}
      <div className="absolute w-[1919px] h-[1116px] left-[-239px] top-[2212px] bg-black blur-[125px]" />

      {/* Roadmap section background */}
      <div className="absolute w-[1919px] h-[789px] left-[-239px] top-[3933px] bg-black blur-[125px]" />

      {/* Additional blurred elements */}
      <div className="absolute w-[975px] h-[593px] left-[930px] top-[-18px] bg-black blur-[102px] rotate-60" />
      <div className="absolute w-[843px] h-[843px] left-[653px] top-[111px] bg-[rgba(255,255,255,0.02)] blur-[243px]" />
      <div className="absolute w-[619px] h-[268px] left-[294px] top-[192px] bg-[rgba(211,211,211,0.04)] blur-[243px]" />
    </div>
  );
};