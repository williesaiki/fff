import React from 'react';

interface PartnerLogoProps {
  src: string;
  alt: string;
  className?: string;
}

export const PartnerLogo: React.FC<PartnerLogoProps> = ({ src, alt, className = '' }) => {
  return (
    <div className={`flex items-center justify-center ${className}`}>
      <img 
        src={src} 
        alt={alt}
        className="h-8 w-auto opacity-50 hover:opacity-100 transition-opacity duration-300 filter grayscale hover:grayscale-0"
        loading="lazy"
      />
    </div>
  );
};