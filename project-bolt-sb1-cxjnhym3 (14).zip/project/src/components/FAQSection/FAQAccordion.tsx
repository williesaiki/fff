import React, { useState } from 'react';
import { FAQItem } from './FAQItem';

const faqItems = [
  {
    question: "What is Flat For Flip?",
    answer: "Flat For Flip is a blockchain-based platform that bridges traditional real estate with the digital world. It allows users to gain exposure to the real estate market using $FFF tokens, with exposure starting from as little as $100."
  },
  {
    question: "What is the mission of Flat For Flip?",
    answer: "Our mission is to democratize real estate investment by making it accessible to everyone through blockchain technology. We aim to bridge the gap between traditional real estate and digital assets."
  },
  {
    question: "What sets Flat For Flip apart from other platforms?",
    answer: "We combine real estate expertise with blockchain technology, offering fractional ownership through tokenization. Our platform is backed by real properties and provides transparent, secure, and accessible investment opportunities."
  },
  {
    question: "How can I start gaining exposure to real estate through Flat For Flip?",
    answer: "Simply purchase $FFF tokens through our platform. Each token represents a fraction of our real estate portfolio, allowing you to gain exposure to the market with minimal investment."
  },
  {
    question: "Are there geographical restrictions for exposure?",
    answer: "No, our platform is designed to be globally accessible. As long as you can purchase and hold $FFF tokens, you can gain exposure to our real estate portfolio regardless of your location."
  },
  {
    question: "What security measures are in place?",
    answer: "We implement industry-leading security protocols, smart contract audits, and multi-signature wallets. All properties are legally verified and properly documented before being tokenized."
  }
];

export const FAQAccordion: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <div className="flex flex-col items-center gap-[8px]">
      {faqItems.map((item, index) => (
        <FAQItem
          key={index}
          question={item.question}
          answer={item.answer}
          isOpen={openIndex === index}
          onClick={() => setOpenIndex(openIndex === index ? null : index)}
        />
      ))}
    </div>
  );
};