import React from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';

export const AboutHeading: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"] // Changed to "end end" to track until the end of content
  });

  // Transform values for parallel movement with clamping
  const y = useTransform(scrollYProgress, [0, 0.8], [0, 200]); // Reduced range to 0.8 to keep visible longer
  const opacity = useTransform(scrollYProgress, [0, 0.8, 0.9], [1, 1, 0]); // Fade out only at the very end

  return (
    <div ref={containerRef} className="flex flex-col items-center md:items-start gap-[10px] w-full md:w-[422px] sticky top-32">
      {/* About us badge */}
      <div 
        className="flex flex-row justify-center items-center px-[15px] py-[5px] w-[130px] h-[34px] rounded-[12px] backdrop-blur-[7.3px]"
        style={{
          background: 'linear-gradient(0deg, rgba(0, 0, 0, 0.06), rgba(0, 0, 0, 0.06)), linear-gradient(224.83deg, rgba(255, 255, 255, 0.13) -7.89%, rgba(255, 255, 255, 0.04) 105.6%)'
        }}
      >
        <span className="w-[60px] h-[17px] font-inter font-normal text-[14px] leading-[17px] text-[#A2A2A2]">
          About us
        </span>
      </div>

      {/* Title container with scroll animation */}
      <motion.div 
        style={{ y, opacity }}
        className="flex flex-col items-center md:items-start"
      >
        {/* "Real" text */}
        <span className="font-inter font-normal text-[40px] md:text-[55px] leading-[1.2] text-white">
          Real
        </span>

        {/* "ESTATE" with vertical line */}
        <div className="flex flex-row items-center">
          <span className="font-inter font-bold text-[72px] md:text-[100px] leading-[1.2] text-neon-green">
            ESTATE
          </span>
          <div className="hidden md:block w-1 h-[107px] bg-neon-green shadow-[0px_0px_38.7px_#C4FC33] ml-[11px]" />
        </div>

        {/* Description with same animation */}
        <p className="font-['Eloquia_Text'] font-light text-[15px] leading-[18px] text-[#9B9B9B] text-center md:text-left w-full md:w-[422px]">
          Revolutionizing real estate investment through blockchain technology and tokenization.
        </p>
      </motion.div>
    </div>
  );
};