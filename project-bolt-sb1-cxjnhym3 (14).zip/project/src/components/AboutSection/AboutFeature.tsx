import React from 'react';

interface AboutFeatureProps {
  title: string;
  description: string;
  number?: number;
  isActive?: boolean;
}

export const AboutFeature: React.FC<AboutFeatureProps> = ({
  title,
  description,
  number,
  isActive = false
}) => {
  return (
    <div 
      className="flex flex-col items-center w-full md:flex-row md:items-start gap-5 md:w-[541px] group"
    >
      {/* Vertical Line - Desktop only */}
      <div className="hidden md:block w-1 h-[149px] relative">
        <div 
          className="absolute w-1 h-[149px] left-0 top-0 transition-all duration-300 
            group-hover:bg-neon-green group-hover:shadow-[0px_0px_28.9px_rgba(196,252,51,0.53)]
            bg-[#ACACAC]"
        />
      </div>

      {/* Content */}
      <div className="flex flex-col items-center w-full gap-6 md:items-start md:gap-[21px] md:w-[599px]">
        {/* Horizontal Line - Mobile only */}
        <div 
          className="w-full h-[2px] md:hidden"
          style={{
            background: 'linear-gradient(90deg, #000000 0%, #C4FC33 49.5%, #000000 100%)'
          }}
        />

        <div className="flex flex-col items-center md:items-start w-full px-4 md:px-0">
          {/* Title */}
          <h3 className="font-inter font-bold text-[20px] md:text-[30px] leading-[1.2] text-white text-center md:text-left mb-4 group-hover:text-neon-green transition-colors">
            {title}
          </h3>

          {/* Description */}
          <p className="font-inter font-normal text-[16px] md:text-[18px] leading-[1.4] text-[#C9C9C9] text-center md:text-left max-w-[450px] group-hover:text-white transition-colors">
            {description}
          </p>
        </div>
      </div>
    </div>
  );
};