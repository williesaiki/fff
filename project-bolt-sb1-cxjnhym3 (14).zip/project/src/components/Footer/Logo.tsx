import React from 'react';

export const Logo: React.FC = () => {
  return (
    <div className="w-32">
      <img
        src="/LOGO_footer.svg"
        alt="FLATFORFLIP"
        className="w-full h-auto"
        loading="eager"
      />
    </div>
  );
};