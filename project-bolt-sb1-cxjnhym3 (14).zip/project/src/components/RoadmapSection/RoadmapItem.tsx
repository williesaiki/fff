import React from 'react';
import { motion } from 'framer-motion';

interface RoadmapItemProps {
  title: string;
  year?: string;
  isYear?: boolean;
  index: number;
}

export const RoadmapItem: React.FC<RoadmapItemProps> = ({
  title,
  year,
  isYear,
  index
}) => {
  const variants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <motion.div
      variants={variants}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="relative"
    >
      <div className="flex items-center justify-center">
        {year && (
          <span className="text-neon-green font-bold text-xl mb-4">
            {year}
          </span>
        )}
        {isYear && (
          <span className="text-neon-green font-bold text-xl">
            {title}
          </span>
        )}
        {!isYear && !year && (
          <div className="max-w-xl text-center">
            <p className="text-gray-300">{title}</p>
          </div>
        )}
      </div>
      {!isYear && (
        <motion.div 
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
          initial={{ scale: 0 }}
          whileInView={{ scale: 1 }}
          viewport={{ once: true }}
          transition={{ delay: index * 0.1 }}
        >
          <div className="w-3 h-3 rounded-full bg-neon-green" />
        </motion.div>
      )}
    </motion.div>
  );
};