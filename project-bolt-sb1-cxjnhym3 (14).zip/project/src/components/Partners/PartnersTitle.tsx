import React from 'react';

export const PartnersTitle: React.FC = () => {
  return (
    <div className="flex items-center justify-center gap-4 mb-12">
      <div className="w-24 h-px bg-[#919191]" />
      <span className="font-inter font-bold text-xs text-[#919191] uppercase tracking-wider">
        Partners
      </span>
      <div className="w-24 h-px bg-[#919191]" />
    </div>
  );
};