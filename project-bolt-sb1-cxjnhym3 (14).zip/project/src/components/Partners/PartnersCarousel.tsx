import React from 'react';
import { motion } from 'framer-motion';
import { usePartnerImages } from './hooks/usePartnerImages';
import { CarouselTrack } from './CarouselTrack';

export const PartnersCarousel: React.FC = () => {
  const images = usePartnerImages();

  return (
    <div className="relative w-full overflow-hidden bg-gradient-to-r from-black via-transparent to-black">
      <div className="max-w-7xl mx-auto py-12">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="mb-8 text-center"
        >
          <span className="text-gray-400 text-lg">Trusted by industry leaders</span>
        </motion.div>
        
        <CarouselTrack images={images} direction="left" />
        <CarouselTrack images={images} direction="right" />
      </div>
    </div>
  );
};