import React from 'react';
import { Linkedin, Twitter, Send, MessageSquare } from 'lucide-react';

const socialLinks = [
  { icon: Linkedin, href: '#' },
  { icon: Twitter, href: '#' },
  { icon: Send, href: '#' },
  { icon: MessageSquare, href: '#' }
];

export const SocialLinks: React.FC = () => {
  return (
    <div className="flex justify-center gap-4">
      {socialLinks.map((social, index) => {
        const Icon = social.icon;
        return (
          <a
            key={index}
            href={social.href}
            className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-neon-green transition-colors"
            target="_blank"
            rel="noopener noreferrer"
          >
            <Icon size={24} />
          </a>
        );
      })}
    </div>
  );
};