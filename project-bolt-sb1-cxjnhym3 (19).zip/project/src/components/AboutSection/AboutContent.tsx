import React from 'react';
import { motion } from 'framer-motion';

interface AboutContentProps {
  isActive: boolean;
  title: string;
  description: string;
}

export const AboutContent: React.FC<AboutContentProps> = ({ isActive, title, description }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ 
        opacity: isActive ? 1 : 0.3,
        y: isActive ? 0 : 20
      }}
      transition={{ duration: 0.5 }}
      className="space-y-4"
    >
      <h3 className="text-2xl font-bold">{title}</h3>
      <p className="text-gray-400">{description}</p>
    </motion.div>
  );
};