import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';

export const ParallaxImage: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  // Smooth parallax effect - image moves 20% slower than scroll
  const y = useTransform(scrollYProgress, [0, 1], ["0%", "-20%"]);

  return (
    <div 
      ref={containerRef}
      className="relative w-full h-[800px] overflow-hidden rounded-2xl"
    >
      <motion.div
        style={{ y }}
        className="absolute inset-0 w-full h-[1000px]" // Extra height for parallax movement
      >
        <img
          src="/real-estate-image.jpg"
          alt="Modern real estate development"
          className="w-full h-full object-cover"
          loading="eager"
        />
      </motion.div>
    </div>
  );
};