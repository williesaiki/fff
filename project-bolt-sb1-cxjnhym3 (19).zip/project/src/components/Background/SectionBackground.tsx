import React from 'react';

interface SectionBackgroundProps {
  className?: string;
}

export const SectionBackground: React.FC<SectionBackgroundProps> = ({ className = '' }) => {
  return (
    <div 
      className={`absolute inset-0 -z-20 bg-gradient-to-b from-black/95 to-black ${className}`}
      style={{
        backdropFilter: 'blur(100px)'
      }}
    />
  );
};