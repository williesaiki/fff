import React from 'react';
import { motion } from 'framer-motion';
import { SquareProps } from './types';

export const BlurredSquare: React.FC<SquareProps> = ({
  size = 48,
  rotation = 90,
  left,
  top,
  delay = 0
}) => {
  return (
    <motion.div
      className="absolute backdrop-blur-[4.55px] rounded-lg"
      style={{
        width: size,
        height: size + 1, // 49px height as specified
        left,
        top,
        transform: `rotate(${rotation}deg)`,
        background: 'linear-gradient(0deg, rgba(0, 0, 0, 0.06), rgba(0, 0, 0, 0.06)), linear-gradient(224.83deg, rgba(255, 255, 255, 0.13) -7.89%, rgba(255, 255, 255, 0.04) 105.6%)'
      }}
      initial={{ scale: 0.95, opacity: 0.8 }}
      animate={{
        scale: [0.95, 1.05, 0.95],
        opacity: [0.8, 1, 0.8],
        rotate: [rotation, rotation - 5, rotation]
      }}
      transition={{
        duration: 6,
        repeat: Infinity,
        ease: "easeInOut",
        delay: delay + 0.3
      }}
    />
  );
};