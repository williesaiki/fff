export interface TimelineItemType {
  type: 'year' | 'item';
  content: string;
};