import React from 'react';

interface RoadmapItemProps {
  text: string;
  isYear?: boolean;
  isLast?: boolean;
}

export const RoadmapItem: React.FC<RoadmapItemProps> = ({ text, isYear, isLast }) => {
  return (
    <div className="flex flex-col items-center gap-1">
      <div className="flex justify-center items-center w-full max-w-[400px]">
        <span className={`text-center ${
          isYear 
            ? 'text-[14px] font-bold text-neon-green drop-shadow-[0_0_11.6px_rgba(196,252,51,0.33)]' 
            : 'text-[15px] font-light text-[#E7E7E7]'
        }`}>
          {text}
        </span>
      </div>
      {(!isYear || text === "2025") && (
        <div className="w-[5px] h-[45px]">
          <div 
            className="absolute w-[5px] h-[45px] rounded-[2px]"
            style={{
              background: 'linear-gradient(180deg, rgba(196,252,51,0.2) 0%, rgba(196,252,51,1) 100%)',
              boxShadow: '0px 0px 19.6px rgba(196,252,51,0.39)'
            }}
          />
        </div>
      )}
    </div>
  );
};