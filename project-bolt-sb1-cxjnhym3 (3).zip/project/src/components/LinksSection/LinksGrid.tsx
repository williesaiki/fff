import React from 'react';
import { motion } from 'framer-motion';

const links = [
  { 
    title: 'Whitepaper',
    href: '/whitepaper_flat_for_flip.pdf',
    type: 'application/pdf'
  },
  { 
    title: 'Pitchdeck',
    href: '/pitchdeck_flat_for_flip.pdf',
    type: 'application/pdf'
  },
  { 
    title: 'Tokenomics',
    href: '/tokenomics_flat_for_flip.pdf',
    type: 'application/pdf'
  }
];

export const LinksGrid: React.FC = () => {
  return (
    <div className="flex flex-col md:flex-row justify-center gap-4 max-w-3xl mx-auto">
      {links.map((link, index) => (
        <motion.a
          key={link.title}
          href={link.href}
          download={`${link.title.toLowerCase()}.pdf`}
          type={link.type}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className="w-full md:w-auto px-8 py-3 rounded-lg font-medium border border-neon-green bg-black hover:bg-neon-green hover:text-black transition-all duration-300 text-center"
        >
          {link.title}
        </motion.a>
      ))}
    </div>
  );
};