import React from 'react';

export const GradientGrid: React.FC = () => {
  return (
    <div className="fixed inset-0 z-0 pointer-events-none">
      {/* Base dark background */}
      <div className="absolute inset-0 bg-black" />
      
      {/* Gradient grid overlay */}
      <div 
        className="absolute inset-0 opacity-[0.15]"
        style={{
          backgroundImage: `
            linear-gradient(to bottom,
              transparent,
              rgba(255,255,255,0.12) 20%,
              rgba(255,255,255,0.12) 80%,
              transparent
            ),
            linear-gradient(to right,
              transparent,
              rgba(255,255,255,0.12) 20%,
              rgba(255,255,255,0.12) 80%,
              transparent
            ),
            linear-gradient(rgba(255,255,255,0.12) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.12) 1px, transparent 1px)
          `,
          backgroundSize: '100% 100%, 100% 100%, 20px 20px, 20px 20px'
        }}
      />
    </div>
  );
};