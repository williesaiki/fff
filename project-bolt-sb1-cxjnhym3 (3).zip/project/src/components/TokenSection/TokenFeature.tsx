import React from 'react';
import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';

interface TokenFeatureProps {
  icon: LucideIcon;
  title: string;
  description: string;
  index: number;
}

export const TokenFeature: React.FC<TokenFeatureProps> = ({
  icon: Icon,
  title,
  description,
  index,
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: index * 0.2 }}
      className="p-6 md:p-8 rounded-lg bg-white/5 hover:bg-neon-green/5 transition-all duration-300 group"
    >
      <div className="w-12 h-12 md:w-14 md:h-14 rounded-lg flex items-center justify-center mb-4 md:mb-6 
        bg-white/10 text-white group-hover:bg-neon-green group-hover:text-black transition-all duration-300">
        <Icon size={24} />
      </div>
      <h3 className="text-xl md:text-2xl font-bold mb-3 md:mb-4">{title}</h3>
      <p className="text-sm md:text-base text-gray-400">{description}</p>
    </motion.div>
  );
};