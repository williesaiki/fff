import React from 'react';
import { motion } from 'framer-motion';
import { Linkedin, Twitter } from 'lucide-react';

interface TeamMemberProps {
  name: string;
  role: string;
  imageUrl: string;
  linkedin?: string;
  twitter?: string;
  index: number;
}

export const TeamMember: React.FC<TeamMemberProps> = ({ 
  name, 
  role, 
  imageUrl, 
  linkedin, 
  twitter,
  index 
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: index * 0.2 }}
      className="relative group"
    >
      <div className="rounded-lg overflow-hidden border border-neon-green/20 bg-black">
        <div className="aspect-square relative">
          <img 
            src={imageUrl} 
            alt={name}
            width={300}
            height={300}
            className="w-full h-full object-cover"
            loading={index === 0 ? "eager" : "lazy"}
          />
        </div>
        <div className="p-4 text-center">
          <h3 className="text-xl font-semibold">{name}</h3>
          <p className="text-gray-400 text-sm">{role}</p>
          <div className="flex justify-center gap-4 mt-3">
            {linkedin && (
              <a 
                href={linkedin} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-gray-400 hover:text-neon-green transition-colors"
              >
                <Linkedin size={20} />
              </a>
            )}
            {twitter && (
              <a 
                href={twitter} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-neon-green transition-colors"
              >
                <Twitter size={20} />
              </a>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
};