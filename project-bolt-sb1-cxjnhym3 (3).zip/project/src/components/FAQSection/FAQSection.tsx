import React from 'react';
import { motion } from 'framer-motion';
import { FAQAccordion } from './FAQAccordion';

export const FAQSection: React.FC = () => {
  return (
    <section className="py-16 px-4 relative" id="faq">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <motion.button
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="px-4 py-2 rounded-full bg-white/5 text-sm mb-6"
          >
            FAQ
          </motion.button>
          
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-5xl font-bold mb-4"
          >
            Get to know us
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="text-gray-400"
          >
            For a more in-depth understanding of $FFF please refer to the Whitepaper.
          </motion.p>
        </div>

        <FAQAccordion />
      </div>
    </section>
  );
};