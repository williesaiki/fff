import React from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { useIntersectionObserver } from './hooks/useIntersectionObserver';

interface FeatureProps {
  number: number;
  title: string;
  description: string;
}

export const Feature: React.FC<FeatureProps> = ({ number, title, description }) => {
  const { elementRef, isIntersecting } = useIntersectionObserver();
  const { scrollYProgress } = useScroll({
    target: elementRef,
    offset: ["start end", "end start"]
  });

  const x = useTransform(scrollYProgress, [0, 0.5, 1], [100, 0, 0]);
  const opacity = useTransform(scrollYProgress, [0, 0.3, 1], [0, 1, 1]);

  return (
    <motion.div
      ref={elementRef}
      style={{ x, opacity }}
      className={`flex gap-6 items-start transition-colors duration-300 ${
        isIntersecting ? 'bg-white/5' : 'bg-transparent'
      } rounded-lg p-6`}
    >
      <div className={`w-px h-full ${
        isIntersecting ? 'bg-neon-green' : 'bg-neon-green/30'
      } transition-colors duration-300`} />
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <span className={`${
            isIntersecting ? 'text-neon-green' : 'text-gray-400'
          } transition-colors duration-300`}>
            {number}.
          </span>
          <h3 className={`text-2xl font-bold ${
            isIntersecting ? 'text-white' : 'text-gray-400'
          } transition-colors duration-300`}>
            {title}
          </h3>
        </div>
        <p className={`${
          isIntersecting ? 'text-gray-300' : 'text-gray-500'
        } max-w-xl transition-colors duration-300`}>
          {description}
        </p>
      </div>
    </motion.div>
  );
};