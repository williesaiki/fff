import React from 'react';
import { motion } from 'framer-motion';
import { usePartnerImages } from './hooks/usePartnerImages';

export const Partners: React.FC = () => {
  const images = usePartnerImages();

  return (
    <div className="w-full overflow-x-auto scrollbar-hide">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="flex items-center justify-start gap-8 min-w-max px-4"
      >
        {images.map((src, index) => (
          <div 
            key={src} 
            className="flex-shrink-0 w-48 h-24 bg-white/5 rounded-lg overflow-hidden"
          >
            <img
              src={src}
              alt={`Partner ${index + 1}`}
              className="w-full h-full object-contain filter grayscale hover:grayscale-0 transition-all duration-300 opacity-70 hover:opacity-100"
              loading={index === 0 ? "eager" : "lazy"}
            />
          </div>
        ))}
      </motion.div>
    </div>
  );
};