import React from 'react';
import { motion } from 'framer-motion';
import { Logo as SharedLogo } from '../Logo';

export const Logo: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      className="flex justify-center"
    >
      <SharedLogo className="h-12" />
    </motion.div>
  );
};