import React from 'react';
import { motion } from 'framer-motion';
import { useScrollToTop } from './useScrollToTop';
import { LogoImage } from './LogoImage';

export const LogoContainer: React.FC = () => {
  const { scrollToTop } = useScrollToTop();

  return (
    <motion.button
      onClick={scrollToTop}
      className="px-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      <LogoImage />
    </motion.button>
  );
};