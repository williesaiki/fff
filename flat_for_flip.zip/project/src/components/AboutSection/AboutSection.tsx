import React from 'react';
import { motion } from 'framer-motion';
import { AboutHeading } from './AboutHeading';
import { AboutFeatures } from './AboutFeatures';
import { GridPattern } from '../Background/GridPattern';
import { SectionDivider } from '../Background/SectionDivider';

export const AboutSection: React.FC = () => {
  return (
    <section className="py-32 px-4 relative" id="about">
      <GridPattern />
      
      {/* Top divider */}
      <SectionDivider className="top-0 -translate-y-1/2" />
      
      {/* Bottom divider */}
      <SectionDivider className="bottom-0 translate-y-1/2" />
      
      <div className="max-w-7xl mx-auto relative">
        <div className="grid md:grid-cols-2 gap-12 md:gap-6">
          <div className="mt-0 md:mt-[-75px] ml-0 md:ml-[45px] w-full">
            <AboutHeading />
          </div>
          <div className="w-full overflow-x-hidden">
            <AboutFeatures />
          </div>
        </div>
      </div>
    </section>
  );
};