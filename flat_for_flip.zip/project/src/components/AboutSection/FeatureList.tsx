import React from 'react';
import { Feature } from './Feature';
import { motion } from 'framer-motion';

interface FeatureListProps {
  features: Array<{
    title: string;
    description: string;
  }>;
}

export const FeatureList: React.FC<FeatureListProps> = ({ features }) => {
  return (
    <motion.div 
      className="space-y-12 relative"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      {features.map((feature, index) => (
        <Feature
          key={index}
          number={index + 1}
          title={feature.title}
          description={feature.description}
        />
      ))}
    </motion.div>
  );
};