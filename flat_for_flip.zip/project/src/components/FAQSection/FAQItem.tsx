import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface FAQItemProps {
  question: string;
  answer: string;
  isOpen: boolean;
  onClick: () => void;
}

export const FAQItem: React.FC<FAQItemProps> = ({
  question,
  answer,
  isOpen,
  onClick,
}) => {
  return (
    <motion.div 
      className="flex flex-col items-center w-full md:w-[709px]"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
    >
      <button
        onClick={onClick}
        className={`w-full flex flex-col justify-center items-center px-[17px] py-[7px] transition-all duration-300 ${
          isOpen 
            ? 'bg-neon-green shadow-[0px_0px_30.7px_rgba(196,252,51,0.28)] rounded-t-[6px]' 
            : 'bg-[rgba(10,10,10,0.82)] border-[0.5px] border-[rgba(248,248,248,0.1)] rounded-[6px] hover:bg-[rgba(20,20,20,0.82)]'
        }`}
      >
        <span 
          className={`font-inter text-center ${
            isOpen 
              ? 'font-bold text-[18px] leading-[22px] text-black' 
              : 'font-medium text-[15px] leading-[18px] text-[#C2C2C2]'
          }`}
        >
          {question}
        </span>
      </button>

      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ 
              height: 'auto', 
              opacity: 1,
              transition: {
                height: {
                  duration: 0.4,
                  ease: [0.04, 0.62, 0.23, 0.98]
                },
                opacity: { duration: 0.25, delay: 0.15 }
              }
            }}
            exit={{ 
              height: 0, 
              opacity: 0,
              transition: {
                height: {
                  duration: 0.3,
                  ease: [0.04, 0.62, 0.23, 0.98]
                },
                opacity: { duration: 0.2 }
              }
            }}
            className="w-full"
          >
            <div className="w-full flex justify-center items-center px-4 py-6 bg-[rgba(10,10,10,0.82)] border-[0.5px] border-t-0 border-[rgba(248,248,248,0.09)] rounded-b-[6px]">
              <p className="w-full md:w-[450px] font-inter font-medium text-[15px] leading-[18px] text-center text-[#8E8E8E]">
                {answer}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};