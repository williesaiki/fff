import React from 'react';
import { motion } from 'framer-motion';

interface StaticSquareProps {
  className?: string;
  scale?: number;
  rotate?: number;
}

export const StaticSquare: React.FC<StaticSquareProps> = ({
  className = '',
  scale = 1.5, // Increased default scale
  rotate = 0
}) => {
  return (
    <motion.img
      src="/kwadraty/Frame 16.svg"
      alt=""
      className={`absolute w-[120px] h-[120px] pointer-events-none ${className}`} // Increased base size
      initial={{ opacity: 0, scale: 0.8 }}
      whileInView={{ opacity: 1, scale }}
      transition={{ duration: 0.6 }}
      style={{ 
        transform: `rotate(${rotate}deg)`,
        filter: 'drop-shadow(0px 0px 20px rgba(196, 252, 51, 0.2))'
      }}
      draggable={false}
    />
  );
};