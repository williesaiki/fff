import { useMemo } from 'react';

export const usePartnerImages = () => {
  return useMemo(() => [
    '/partnerzy/1.png',
    '/partnerzy/2.png',
    '/partnerzy/3.png',
    '/partnerzy/4.png',
    '/partnerzy/5.png',
    '/partnerzy/6.png',
    '/partnerzy/7.png'
  ], []);
};