import React from 'react';
import { useNavigate } from 'react-router-dom';

interface LaunchAppButtonProps {
  className?: string;
}

export const LaunchAppButton: React.FC<LaunchAppButtonProps> = ({ 
  className = "bg-neon-green text-black px-6 py-2 rounded-lg font-semibold hover:bg-neon-green/90 transition-colors"
}) => {
  const navigate = useNavigate();

  return (
    <button 
      onClick={() => navigate('/coming-soon')}
      className={className}
    >
      Launch App
    </button>
  );
};