import React from 'react';
import { motion } from 'framer-motion';
import { MainBackground } from '../components/Background/MainBackground';
import { GradientGrid } from '../components/Background/GradientGrid';

export const ComingSoon: React.FC = () => {
  return (
    <div className="min-h-screen bg-black text-white overflow-hidden">
      <MainBackground />
      <GradientGrid />
      
      <div className="relative z-10 min-h-screen flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <h1 className="text-6xl md:text-7xl font-bold mb-4">
            Coming <span className="text-neon-green">Soon</span>
          </h1>
          <p className="text-gray-400 text-lg">
            We're working hard to bring you something amazing
          </p>
        </motion.div>
      </div>
    </div>
  );
};