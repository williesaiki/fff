import React from 'react';
import { motion } from 'framer-motion';
import { TeamMember } from './TeamMember';

const teamMembers = [
  {
    name: "John Smith",
    role: "Founder & CEO",
    imageUrl: "/1img_flat_for_flip.jpg",
    linkedin: "https://linkedin.com",
    twitter: "https://twitter.com"
  },
  {
    name: "Sarah Johnson",
    role: "CTO",
    imageUrl: "/2img_flat_for_flip.jpg",
    linkedin: "https://linkedin.com",
    twitter: "https://twitter.com"
  },
  {
    name: "Michael Chen",
    role: "Head of Operations",
    imageUrl: "/3img_flat_for_flip.jpg",
    linkedin: "https://linkedin.com",
    twitter: "https://twitter.com"
  },
  {
    name: "Emma Williams",
    role: "Chief Marketing Officer",
    imageUrl: "/4img_flat_for_flip.jpg",
    linkedin: "https://linkedin.com",
    twitter: "https://twitter.com"
  }
];

export const TeamSection: React.FC = () => {
  return (
    <section className="py-16 px-4" id="team">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <motion.button
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="px-4 py-2 rounded-full bg-white/5 text-sm mb-6"
          >
            Who's behind?
          </motion.button>
          
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-5xl font-bold mb-4"
          >
            Our Team
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-gray-400 max-w-2xl mx-auto"
          >
            Meet our dedicated team of professionals working to revolutionize real estate investment through blockchain technology.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {teamMembers.map((member, index) => (
            <TeamMember
              key={member.name}
              {...member}
              index={index}
            />
          ))}
        </div>
      </div>
    </section>
  );
};