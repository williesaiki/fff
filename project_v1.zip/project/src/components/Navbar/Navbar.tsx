import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Logo } from '../Logo';
import { MobileMenuButton } from './MobileMenuButton';
import { MobileMenu } from './MobileMenu';
import { NavLinks } from './NavLinks';

export const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed w-full top-0 z-50 transition-colors ${
        isMenuOpen ? 'bg-black' : 'bg-black/80 backdrop-blur-sm'
      }`}
    >
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center h-16">
          <div className="px-8">
            <Logo />
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center justify-center flex-1">
            <NavLinks />
          </div>

          <div className="px-8">
            <button className="hidden md:block bg-neon-green text-black px-6 py-2 rounded-lg font-semibold text-sm hover:bg-neon-green/90 transition-colors">
              Launch App
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="block md:hidden px-4">
            <MobileMenuButton 
              isOpen={isMenuOpen} 
              onClick={() => setIsMenuOpen(!isMenuOpen)} 
            />
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className="md:hidden">
        <MobileMenu 
          isOpen={isMenuOpen} 
          onClose={() => setIsMenuOpen(false)} 
        />
      </div>
    </motion.nav>
  );
};