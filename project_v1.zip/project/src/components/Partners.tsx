import React from 'react';
import { motion } from 'framer-motion';

export const Partners: React.FC = () => {
  return (
    <div className="mt-8">
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        className="flex justify-center"
      >
        <img
          src="/Partners.png"
          alt="Our Partners"
          className="max-w-full h-auto opacity-70 hover:opacity-100 transition-opacity duration-300"
          draggable={false}
          loading="eager"
        />
      </motion.div>
    </div>
  );
};