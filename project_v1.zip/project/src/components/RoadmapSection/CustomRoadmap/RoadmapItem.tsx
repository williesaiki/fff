import React from 'react';

interface RoadmapItemProps {
  text: string;
  isYear?: boolean;
}

export const RoadmapItem: React.FC<RoadmapItemProps> = ({ text, isYear }) => {
  return (
    <div className="flex flex-col items-center gap-6">
      <div className="flex justify-center items-center w-full">
        <span className={`text-center ${
          isYear 
            ? 'text-[15px] font-bold text-neon-green drop-shadow-[0_0_11.6px_rgba(196,252,51,0.33)]' 
            : 'text-[18px] font-light text-[#E7E7E7]'
        }`}>
          {text}
        </span>
      </div>
      {!isYear && (
        <div className="w-[5px] h-[35px]">
          <div className="absolute w-[5px] h-[35px] bg-neon-green shadow-[0_0_19.6px_rgba(196,252,51,0.39)] rounded-[2px]" />
        </div>
      )}
    </div>
  );
};