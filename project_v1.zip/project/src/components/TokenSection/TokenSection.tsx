import React from 'react';
import { motion } from 'framer-motion';
import { Globe, TrendingUp, DollarSign } from 'lucide-react';
import { TokenFeature } from './TokenFeature';

const features = [
  {
    icon: Globe,
    title: "Real estate market",
    description: "The $FFF token provides exposure to the real estate market.",
  },
  {
    icon: TrendingUp,
    title: "Deflationary tokenomics",
    description: "Token value increases as the project develops.",
    highlight: true,
  },
  {
    icon: DollarSign,
    title: "Yield",
    description: "Take advantage of the real estate market's potential starting from $100.",
  },
];

export const TokenSection: React.FC = () => {
  return (
    <section className="py-12 md:py-16 px-4 relative overflow-hidden" id="token">
      <div className="max-w-7xl mx-auto">
        {/* Opening Image */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 1 }}
          className="w-full max-w-[1200px] mx-auto mb-24"
        >
          <img
            src="/opening.svg"
            alt="We are opening the real estate market to everyone"
            className="w-full h-auto"
            loading="eager"
          />
        </motion.div>

        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4"
          >
            $FFF Token
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-gray-400 max-w-2xl mx-auto text-sm sm:text-base md:text-lg"
          >
            Our token is designed to provide real value backed by real estate assets,
            combining traditional investment with blockchain innovation.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
          {features.map((feature, index) => (
            <TokenFeature
              key={feature.title}
              {...feature}
              index={index}
            />
          ))}
        </div>
      </div>
    </section>
  );
};