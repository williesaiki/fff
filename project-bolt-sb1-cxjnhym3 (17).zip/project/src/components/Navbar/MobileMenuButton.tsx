import React from 'react';
import { Menu } from 'lucide-react';

interface MobileMenuButtonProps {
  isOpen: boolean;
  onClick: () => void;
}

export const MobileMenuButton: React.FC<MobileMenuButtonProps> = ({ onClick }) => {
  return (
    <button 
      onClick={onClick}
      className="p-2 text-neon-green hover:bg-white/5 rounded-lg transition-colors"
    >
      <Menu size={24} />
    </button>
  );
};