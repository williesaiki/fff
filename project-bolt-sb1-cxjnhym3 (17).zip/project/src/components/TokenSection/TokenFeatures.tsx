import React from 'react';
import { TokenFeature } from './TokenFeature';

const features = [
  {
    icon: '/fff_token_svgs/Frame 63.svg',
    title: 'Real estate market',
    description: 'The $FFF token provides exposure to the real estate market.',
  },
  {
    icon: '/fff_token_svgs/Frame 64.svg',
    title: 'Deflationary tokenomics',
    description: 'Token value increases as the project develops.',
  },
  {
    icon: '/fff_token_svgs/Frame 65.svg',
    title: 'Yield',
    description:
      "Take advantage of the real estate market's potential starting from $100.",
  },
];

export const TokenFeatures: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
      {features.map((feature, index) => (
        <TokenFeature key={feature.title} {...feature} index={index} />
      ))}
    </div>
  );
};
