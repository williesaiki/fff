import React from 'react';
import { motion } from 'framer-motion';

interface SquareProps {
  className?: string;
  variant: 'rect20' | 'rect25';
  rotate?: number;
}

export const Square: React.FC<SquareProps> = ({ 
  className = '', 
  variant,
  rotate = 0 
}) => {
  const src = variant === 'rect20' ? '/kwadraty/Rectangle 20.svg' : '/kwadraty/Rectangle 25.svg';

  return (
    <motion.img
      src={src}
      alt=""
      className={`absolute w-[45px] h-[45px] ${className}`}
      style={{ transform: `rotate(${rotate}deg)` }}
      initial={{ opacity: 0, scale: 0.8 }}
      whileInView={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.6 }}
      aria-hidden="true"
      draggable={false}
    />
  );
};