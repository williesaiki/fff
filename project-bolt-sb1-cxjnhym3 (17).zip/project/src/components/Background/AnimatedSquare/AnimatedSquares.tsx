import React from 'react';
import { SquareGroup } from './SquareGroup';

export const AnimatedSquares: React.FC = () => {
  const squares = [
    { left: 1285.07, top: 3951, rotation: 16.98, delay: 0 },
    { left: 196.12, top: 2945.1, rotation: 16.98, delay: 0.3 },
    // Add more positions as needed based on the design
  ];

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {squares.map((square, index) => (
        <SquareGroup
          key={index}
          left={square.left}
          top={square.top}
          rotation={square.rotation}
          delay={square.delay}
        />
      ))}
    </div>
  );
};