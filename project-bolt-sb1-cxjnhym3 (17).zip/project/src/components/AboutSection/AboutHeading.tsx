import React, { useState, useEffect, useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { useMediaQuery } from '@mui/material';

export const AboutHeading: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const isDesktop = useMediaQuery('(min-width: 1024px)');

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start end', 'end start'],
  });

  const y = useTransform(scrollYProgress, [0, 1], [-170, 640]);

  const words = ['ESTATE', 'YIELD', 'TEAM'];
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [displayedText, setDisplayedText] = useState('');
  const [isTyping, setIsTyping] = useState(true);

  const typingSpeed = 100; // Czas pisania pojedynczego znaku
  const deletingSpeed = 50; // Czas usuwania pojedynczego znaku
  const pauseDuration = 1500; // Czas pauzy po napisaniu słowa

  useEffect(() => {
    let timeout: NodeJS.Timeout;

    const typeEffect = () => {
      const currentWord = words[currentWordIndex];

      if (isTyping) {
        if (displayedText.length < currentWord.length) {
          // Dodajemy kolejny znak z bieżącego słowa
          setDisplayedText((prev) => currentWord.slice(0, prev.length + 1));
        } else {
          // Po zakończeniu pisania słowa pauza
          timeout = setTimeout(() => setIsTyping(false), pauseDuration);
        }
      } else {
        if (displayedText.length > 0) {
          // Usuwamy znaki z wyświetlanego tekstu
          setDisplayedText((prev) => prev.slice(0, prev.length - 1));
        } else {
          // Przechodzimy do kolejnego słowa
          setCurrentWordIndex((prevIndex) => (prevIndex + 1) % words.length);
          setIsTyping(true); // Wróć do trybu pisania
        }
      }
    };

    // Wywołanie efektu pisania/usuwania co określony czas
    timeout = setTimeout(typeEffect, isTyping ? typingSpeed : deletingSpeed);

    return () => clearTimeout(timeout);
  }, [displayedText, isTyping, currentWordIndex, words]);

  return (
    <div
      ref={containerRef}
      className="flex flex-col items-center md:items-start gap-[10px] w-full md:w-[422px] sticky top-32"
    >
      {/* "About us" badge */}
      <motion.div
        style={isDesktop ? { y } : {}}
        className="flex flex-row justify-center items-center px-[15px] py-[5px] w-[130px] h-[34px] rounded-[12px] backdrop-blur-[7.3px] bg-gradient-to-r from-[#0E0E0E] to-[#1B1B1B]"
      >
        <span className="w-[60px] h-[17px] font-inter font-normal text-[14px] leading-[17px] text-[#A2A2A2]">
          About us
        </span>
      </motion.div>

      <motion.div
        style={isDesktop ? { y } : {}}
        className="flex flex-col items-center md:items-start"
      >
        {/* "Real" text */}
        <span className="font-inter font-normal text-[40px] md:text-[55px] leading-[1.2] text-white">
          Real
        </span>

        {/* Dynamic word with typing effect */}
        <div className="flex flex-row items-center">
          <span
            className="font-inter font-bold text-[72px] md:text-[100px] leading-[1.2] text-neon-green"
            style={{
              display: 'inline-block',
              overflow: 'hidden',
              whiteSpace: 'nowrap',
            }}
          >
            {displayedText}
          </span>
          {/* Zielona kreska (kursor) */}
          <div className="md:block w-1 h-[107px] bg-neon-green shadow-[0px_0px_38.7px_#C4FC33] ml-[11px]" />
        </div>

        {/* Description */}
        <p className="font-['Eloquia_Text'] font-light text-[15px] leading-[18px] text-[#9B9B9B] text-center md:text-left w-full md:w-[422px] mt-[20px]">
          Revolutionizing real estate investment through blockchain technology
          and tokenization.
        </p>
      </motion.div>
    </div>
  );
};
