import React from 'react';
import { motion } from 'framer-motion';

export const CityVector: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      transition={{ duration: 1 }}
      className="absolute top-[15px] left-0 right-0 w-full z-[-1]" // Changed from top-[25px] to top-[15px]
    >
      <div className="absolute inset-0 bg-gradient-to-b from-black/90 to-transparent pointer-events-none" />
      <img
        src="/city_Vector.svg"
        alt=""
        className="w-full h-auto object-cover opacity-[0.02]"
        aria-hidden="true"
      />
    </motion.div>
  );
};