import React from 'react';
import { TimelineItem } from './TimelineItem';
import { timelineData } from './timelineData';

export const RoadmapTimeline: React.FC = () => {
  return (
    <div className="relative max-w-3xl mx-auto">
      <div className="absolute left-1/2 top-0 bottom-0 w-px bg-neon-green/20" />
      <div className="space-y-16">
        {timelineData.map((item, index) => (
          <TimelineItem
            key={index}
            item={item}
            index={index}
          />
        ))}
      </div>
    </div>
  );
};