export interface SocialLink {
  icon: string;
  href: string;
  label: string;
}