import React from 'react';

interface SectionDividerProps {
  className?: string;
}

export const SectionDivider: React.FC<SectionDividerProps> = ({ className = '' }) => {
  return (
    <div 
      className={`absolute left-0 right-0 h-[500px] pointer-events-none ${className}`}
      style={{
        background: `linear-gradient(
          180deg, 
          transparent 0%,
          rgba(0, 0, 0, 0.98) 50%,
          transparent 100%
        )`,
        filter: 'blur(10px)'
      }}
    />
  );
};