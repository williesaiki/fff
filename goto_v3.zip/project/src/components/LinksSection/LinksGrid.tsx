import React from 'react';
import { motion } from 'framer-motion';

const links = [
  { 
    title: 'Whitepaper',
    href: '/docs/whitepaper_flat_for_flip.pdf'
  },
  { 
    title: 'Pitchdeck',
    href: '/docs/pitchdeck_flat_for_flip.pdf'
  },
  { 
    title: 'Tokenomics',
    href: '/docs/tokenomics_flat_for_flip.pdf'
  }
];

export const LinksGrid: React.FC = () => {
  const handleClick = (href: string) => {
    window.open(href, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="flex flex-col md:flex-row justify-center gap-4 max-w-3xl mx-auto">
      {links.map((link, index) => (
        <motion.button
          key={link.title}
          onClick={() => handleClick(link.href)}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className="w-full md:w-auto px-8 py-3 rounded-lg font-medium border border-neon-green bg-black hover:bg-neon-green hover:text-black transition-all duration-300 text-center"
        >
          {link.title}
        </motion.button>
      ))}
    </div>
  );
};