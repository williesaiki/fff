import React from 'react';
import { motion } from 'framer-motion';

export const TokenHeader: React.FC = () => {
  return (
    <div className="flex flex-col items-center gap-2 w-[704px] h-[135px] mx-auto">
      {/* Badge */}
      <div className="hidden flex-row justify-center items-center px-[15px] py-[5px] w-[130px] h-[34px] rounded-[12px]"
        style={{
          background: 'linear-gradient(0deg, rgba(0, 0, 0, 0.06), rgba(0, 0, 0, 0.06)), linear-gradient(224.83deg, rgba(255, 255, 255, 0.13) -7.89%, rgba(255, 255, 255, 0.04) 105.6%)'
        }}
      >
        <span className="w-[40px] h-[17px] font-inter text-[14px] leading-[17px] text-[#A2A2A2]">
          About
        </span>
      </div>

      {/* Title */}
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        className="w-[704px] h-[67px] font-inter font-semibold text-[55px] leading-[67px] text-center text-white"
      >
        $FFF Token
      </motion.h2>
      
      {/* Description */}
      <motion.p
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        className="w-[704px] h-[18px] font-['Eloquia_Text'] font-light text-[15px] leading-[18px] text-center text-[#9B9B9B]"
      >
        Lorem Ipsum is simply dummy text of the printing and typesetting industry.
      </motion.p>
    </div>
  );
};