import React from 'react';
import { motion } from 'framer-motion';
import { LinksGrid } from './LinksGrid';
import { SquaresGroup } from '../DecorativeSquares/SquaresGroup';

export const LinksSection: React.FC = () => {
  return (
    <section className="py-16 px-4 relative">
      <div className="max-w-7xl mx-auto text-center relative">
        {/* Decorative squares */}
        <SquaresGroup
          className="left-4 top-12 md:left-12"
          rotate={15}
          scale={0.85}
        />
        <SquaresGroup
          className="right-4 bottom-12 md:right-12"
          rotate={-25}
          scale={0.85}
        />
        
        <div 
          className="inline-flex justify-center items-center px-[15px] py-[5px] w-[155px] h-[34px] rounded-[12px] backdrop-blur-[7.3px]"
          style={{
            background: 'linear-gradient(0deg, rgba(0, 0, 0, 0.06), rgba(0, 0, 0, 0.06)), linear-gradient(224.83deg, rgba(255, 255, 255, 0.13) -7.89%, rgba(255, 255, 255, 0.04) 105.6%)'
          }}
        >
          <span className="font-inter font-normal text-[14px] leading-[17px] text-[#A2A2A2]">
            DOCS
          </span>
        </div>
        
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          className="font-inter font-semibold text-[55px] leading-[67px] text-center text-white mb-4 mt-6"
        >
          Check our Links
        </motion.h2>
        
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="font-['Eloquia_Text'] font-light text-[15px] leading-[18px] text-center text-[#9B9B9B] max-w-2xl mx-auto mb-12"
        >
          For a more in-depth understanding of $FFF please refer to the Whitepaper.
        </motion.p>

        <LinksGrid />
      </div>
    </section>
  );
};