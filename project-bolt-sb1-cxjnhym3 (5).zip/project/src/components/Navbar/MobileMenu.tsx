import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu } from 'lucide-react';

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const menuItems = [
  { href: '#about', label: 'About' },
  { href: '#team', label: 'Team' },
  { href: '#token', label: 'Token' },
  { href: '#roadmap', label: 'Roadmap' },
  { href: '#faq', label: 'FAQ' },
  { href: '#docs', label: 'Docs' },
  { href: '/whitepaper_flat_for_flip.pdf', label: 'Whitepaper' },
  { href: '/pitchdeck_flat_for_flip.pdf', label: 'Pitchdeck' },
  { href: '/tokenomics_flat_for_flip.pdf', label: 'Tokenomics' }
];

export const MobileMenu: React.FC<MobileMenuProps> = ({ isOpen, onClose }) => {
  const handleClick = (href: string) => {
    if (href.startsWith('#')) {
      const element = document.querySelector(href);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
        onClose();
      }
    } else {
      window.open(href, '_blank');
      onClose();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="fixed inset-x-0 top-16 bg-black h-[calc(100vh-4rem)]"
        >
          <div className="flex flex-col items-center gap-8 px-4 py-8">
            {/* Menu Items */}
            <nav className="flex flex-col items-center gap-6 w-full">
              {menuItems.map(({ href, label }) => (
                <button
                  key={href}
                  onClick={() => handleClick(href)}
                  className="w-full text-center text-lg font-medium text-[#9B9B9B] hover:text-neon-green hover:text-shadow-neon transition-all"
                >
                  {label}
                </button>
              ))}
            </nav>

            {/* Launch App Button */}
            <button className="w-full max-w-[245px] h-[55px] bg-neon-green text-black font-bold text-lg rounded shadow-[0_0_122.4px_rgba(196,252,51,0.22)] hover:bg-neon-green/90 transition-colors">
              Launch App
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};