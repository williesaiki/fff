import React from 'react';
import { Logo } from './Logo';
import { SocialLinks } from './SocialLinks';
import { FooterText } from './FooterText';

export const FooterContent: React.FC = () => {
  return (
    <div className="flex flex-col items-center space-y-10">
      <Logo />
      <SocialLinks />
      <FooterText />
    </div>
  );
};