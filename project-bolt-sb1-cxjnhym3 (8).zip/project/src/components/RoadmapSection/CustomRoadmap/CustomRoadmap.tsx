import React from 'react';
import { RoadmapItem } from './RoadmapItem';

const roadmapItems = [
  { text: "2023/2024", isYear: true },
  { text: "Building a Web 2.0 community around the project." },
  { text: "Building community and reach on social media (Web 3.0)" },
  { text: "Organizing events for the community" },
  { text: "Internal sales of real estate with a total value of 25 million USD" },
  { text: "Real estate sold through the Flat For Flip community valued at 25 million USD. Generated over 500,000 USD in commissions for community members." },
  { text: "Development of a residential estate conducted by a project in Europe" },
  { text: "2025", isYear: true }
];

export const CustomRoadmap: React.FC = () => {
  return (
    <div className="flex flex-col justify-center items-center gap-6 w-full max-w-[652px] mx-auto px-4">
      {roadmapItems.map((item, index) => (
        <RoadmapItem
          key={index}
          text={item.text}
          isYear={item.isYear}
        />
      ))}
    </div>
  );
};