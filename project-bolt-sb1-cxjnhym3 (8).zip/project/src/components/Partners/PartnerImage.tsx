import React from 'react';

interface PartnerImageProps {
  src: string;
}

export const PartnerImage: React.FC<PartnerImageProps> = ({ src }) => {
  return (
    <div className="flex-shrink-0 w-48 h-24 bg-white/5 rounded-lg overflow-hidden">
      <img
        src={src}
        alt="Partner"
        className="w-full h-full object-contain filter grayscale hover:grayscale-0 transition-all duration-300 opacity-70 hover:opacity-100"
        loading="lazy"
      />
    </div>
  );
};