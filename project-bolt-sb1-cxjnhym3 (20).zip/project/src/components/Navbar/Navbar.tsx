import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Logo } from '../Logo';
import { MobileMenuButton } from './MobileMenuButton';
import { MobileMenu } from './MobileMenu';
import { NavLinks } from './NavLinks';
import { LaunchAppButton } from './LaunchAppButton';

export const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed w-full top-0 z-50 transition-colors ${
        isMenuOpen ? 'bg-black' : 'bg-black/10 backdrop-blur-[1px]'
      }`}
    >
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between h-16">
          <div className="px-8">
            <Logo />
          </div>
          
          <div className="hidden md:flex items-center justify-center flex-1">
            <NavLinks />
          </div>

          <div className="hidden md:block px-8">
            <LaunchAppButton />
          </div>

          <div className="block md:hidden px-8">
            <MobileMenuButton 
              isOpen={isMenuOpen} 
              onClick={() => setIsMenuOpen(!isMenuOpen)} 
            />
          </div>
        </div>
      </div>

      <div className="md:hidden">
        <MobileMenu 
          isOpen={isMenuOpen} 
          onClose={() => setIsMenuOpen(false)} 
        />
      </div>
    </motion.nav>
  );
};