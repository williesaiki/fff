import React from 'react';
import { GreenLine } from './GreenLine';
import { FooterContent } from './FooterContent';

export const Footer: React.FC = () => {
  return (
    <footer className="relative w-full py-16">
      <div className="max-w-7xl mx-auto px-4">
        <GreenLine />
        <FooterContent />
      </div>
    </footer>
  );
};