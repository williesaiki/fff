import React from 'react';
import { motion } from 'framer-motion';
import { TokenHeader } from './TokenHeader';
import { TokenFeatures } from './TokenFeatures';
import { OpeningImage } from './OpeningImage';
import { SquaresGroup } from '../DecorativeSquares/SquaresGroup';

export const TokenSection: React.FC = () => {
  return (
    <section className="py-32 px-4 relative" id="token">
      <div className="max-w-7xl mx-auto">
        <div className="w-full max-w-[704px] mx-auto px-4 mb-16 relative">
          {/* Decorative squares */}
          <SquaresGroup
            className="left-0 top-12 -translate-x-1/2"
            rotate={45}
          />
          <SquaresGroup
            className="right-0 bottom-0 translate-x-1/2"
            rotate={-15}
            scale={0.8}
          />
          
          <div className="flex flex-col items-center gap-2 w-full">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              className="font-inter font-semibold text-[55px] leading-[67px] text-center text-white"
            >
              $FFF Token
            </motion.h2>
            
            <motion.p
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              className="font-['Eloquia_Text'] font-light text-[15px] leading-[17.82px] text-center text-[#9B9B9B]"
            >
              Lorem Ipsum is simply dummy text of the printing and typesetting industry.
            </motion.p>
          </div>
        </div>
        <TokenFeatures />
        <div className="mt-32 relative">
          <SquaresGroup
            className="left-8 top-1/2 -translate-y-1/2"
            rotate={-30}
            scale={0.9}
          />
          <OpeningImage />
        </div>
      </div>
    </section>
  );
}