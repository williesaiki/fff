import React from 'react';

export const Logo: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <button
      onClick={scrollToTop}
      className="hover:opacity-80 transition-opacity"
    >
      <img
        src="/LOGO.svg"
        alt="FlatForFlip"
        className="h-8 w-auto"
        draggable={false}
      />
    </button>
  );
};