import React from 'react';
import { motion } from 'framer-motion';

export const FAQHeader: React.FC = () => {
  return (
    <div className="text-center mb-12">
      <div 
        className="inline-flex justify-center items-center px-[15px] py-[5px] w-[130px] h-[34px] rounded-[12px] backdrop-blur-[7.3px]"
        style={{
          background: 'linear-gradient(0deg, rgba(0, 0, 0, 0.06), rgba(0, 0, 0, 0.06)), linear-gradient(224.83deg, rgba(255, 255, 255, 0.13) -7.89%, rgba(255, 255, 255, 0.04) 105.6%)'
        }}
      >
        <span className="w-[32px] h-[17px] font-inter font-normal text-[14px] leading-[17px] text-[#A2A2A2]">
          FAQ
        </span>
      </div>
      
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        className="text-5xl font-bold mb-4 mt-6"
      >
        Get to know us
      </motion.h2>
      
      <motion.p
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        className="text-gray-400"
      >
        For a more in-depth understanding of $FFF please refer to the Whitepaper.
      </motion.p>
    </div>
  );
};