import React from 'react';
import { motion } from 'framer-motion';

interface SquareProps {
  size?: 'sm' | 'md' | 'lg';
  delay?: number;
  animationType?: 'normal' | 'delay' | 'slow';
  className?: string;
}

export const Square: React.FC<SquareProps> = ({
  size = 'md',
  delay = 0,
  animationType = 'normal',
  className = '',
}) => {
  const sizeClasses = {
    sm: 'w-16 h-16',
    md: 'w-20 h-20',
    lg: 'w-24 h-24',
  };

  const getAnimation = () => {
    switch (animationType) {
      case 'delay':
        return {
          x: [0, -20, 0],
          y: [0, -30, 0],
          rotate: [-5, 0, -5],
        };
      case 'slow':
        return {
          x: [0, 30, 0],
          y: [0, -15, 0],
          rotate: [0, 8, 0],
        };
      default:
        return {
          x: [0, 20, 0],
          y: [0, -20, 0],
          rotate: [0, 5, 0],
        };
    }
  };

  return (
    <motion.div
      className={`absolute bg-neon-green/30 rounded-lg blur-md shadow-lg shadow-neon-green/20 ${sizeClasses[size]} ${className}`}
      initial={{ opacity: 0, scale: 0 }}
      animate={{
        ...getAnimation(),
        opacity: [0.3, 0.5, 0.3],
        scale: [1, 1.1, 1],
      }}
      transition={{
        duration: animationType === 'slow' ? 8 : animationType === 'delay' ? 7 : 6,
        delay,
        repeat: Infinity,
        ease: "easeInOut"
      }}
    />
  );
};