import React from 'react';
import { motion } from 'framer-motion';

interface FloatingSquareProps {
  className?: string;
  delay?: number;
  scale?: number;
  rotate?: number;
}

const FloatingSquare: React.FC<FloatingSquareProps> = ({
  className = '',
  delay = 0,
  scale = 1,
  rotate = 0
}) => {
  return (
    <motion.img
      src="/kwadraty/Frame 16.svg"
      alt=""
      className={`absolute w-[90px] h-[90px] pointer-events-none ${className}`}
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ 
        y: [0, -20, 0],
        rotate: [rotate, rotate + 10, rotate],
        scale: [scale, scale * 1.1, scale],
        opacity: [0.6, 1, 0.6]
      }}
      transition={{
        duration: 6,
        delay,
        repeat: Infinity,
        ease: "easeInOut"
      }}
      style={{
        filter: 'drop-shadow(0px 0px 20px rgba(196, 252, 51, 0.2))'
      }}
      draggable={false}
    />
  );
};

const squares = [
  { className: "top-[20%] left-[10%]", delay: 0, scale: 1.2, rotate: 15 },
  { className: "top-[60%] right-[15%]", delay: 1, scale: 1, rotate: -20 },
  { className: "top-[40%] left-[25%]", delay: 2, scale: 1.4, rotate: 30 },
  { className: "bottom-[30%] right-[20%]", delay: 1.5, scale: 1.1, rotate: -15 },
  { className: "top-[15%] right-[30%]", delay: 2.5, scale: 1.3, rotate: 25 },
  { className: "bottom-[20%] left-[15%]", delay: 0.5, scale: 1.2, rotate: -30 }
];

export const FloatingSquares: React.FC = () => {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {squares.map((square, index) => (
        <FloatingSquare key={index} {...square} />
      ))}
    </div>
  );
};