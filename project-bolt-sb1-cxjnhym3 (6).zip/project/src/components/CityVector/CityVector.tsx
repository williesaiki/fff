import React from 'react';
import { motion } from 'framer-motion';

export const CityVector: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      transition={{ duration: 1 }}
      className="absolute top-[40px] left-0 right-0 w-full z-[-1] h-[300px] overflow-hidden" // Adjusted top from 25px to 40px
    >
      <div className="absolute inset-0 bg-gradient-to-b from-black/90 to-transparent pointer-events-none" />
      <img
        src="/city_Vector.svg"
        alt=""
        className="w-full h-full object-cover opacity-[0.02]"
        aria-hidden="true"
        style={{ objectPosition: 'center top' }}
      />
    </motion.div>
  );
};