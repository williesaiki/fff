import React from 'react';
import { SOCIAL_LINKS } from './constants';

export const SocialLinks: React.FC = () => {
  return (
    <div className="flex items-center gap-[15px]">
      {SOCIAL_LINKS.map(({ icon, href, label }) => (
        <a
          key={label}
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/5 transition-colors"
        >
          <img 
            src={icon} 
            alt={label}
            className="w-5 h-5"
            loading="eager"
          />
        </a>
      ))}
    </div>
  );
};