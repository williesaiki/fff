import React from 'react';
import { Grid } from './Grid';
import { FloatingSquares } from './FloatingSquares';

export const AnimatedBackground: React.FC = () => {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none">
      <Grid />
      <FloatingSquares />
    </div>
  );
};