import React from 'react';
import { HeroTitle } from './HeroTitle';
import { HeroDescription } from './HeroDescription';
import { LaunchAppButton } from './LaunchAppButton';

export const HeroSection: React.FC = () => {
  return (
    <div className="flex flex-col items-center gap-[35px] w-[954px] h-[343px]">
      <div className="flex justify-between items-start w-[954px] h-[152px]">
        <HeroTitle />
      </div>
      <HeroDescription />
      <LaunchAppButton />
    </div>
  );
};