import React from 'react';

export const FooterBackground: React.FC = () => {
  return (
    <div className="absolute inset-0 w-full h-full">
      <img
        src="/Footer (1).svg"
        alt=""
        className="w-full h-full object-cover"
        aria-hidden="true"
      />
    </div>
  );
};