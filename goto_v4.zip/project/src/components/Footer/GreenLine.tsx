import React from 'react';

export const GreenLine: React.FC = () => {
  return (
    <div 
      className="w-full h-[2px] mb-16"
      style={{
        background: 'linear-gradient(90deg, #000000 0%, #C4FC33 49.5%, #000000 100%)'
      }}
    />
  );
};