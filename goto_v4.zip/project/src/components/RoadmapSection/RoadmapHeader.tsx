import React from 'react';
import { motion } from 'framer-motion';

export const RoadmapHeader: React.FC = () => {
  return (
    <>
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 0.8 }}
        transition={{ duration: 1 }}
        className="relative w-full overflow-hidden mb-16"
      >
        <img
          src="/Roadmap.svg"
          alt="We are opening the real estate market to everyone"
          className="w-full max-w-[1200px] mx-auto"
        />
      </motion.div>

      <div className="text-center mb-24 relative z-10">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="inline-block px-4 py-2 rounded-full bg-zinc-900 text-sm mb-6"
        >
          What is our mission
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          className="text-5xl font-bold mb-6"
        >
          Roadmap
        </motion.h2>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="text-gray-400/80 max-w-2xl mx-auto text-lg"
        >
          Our mission is to create a seamless bridge between the traditional
          real estate market and the digital world, incorporating blockchain and
          Web 3.0 technologies. We aim to generate lucrative investment
          opportunities for our community members, utilizing the experience and
          expertise of both traditional real estate investors and digital asset
          investors looking to diversify their portfolios
        </motion.p>
      </div>
    </>
  );
};
