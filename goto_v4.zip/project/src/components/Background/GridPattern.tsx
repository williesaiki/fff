import React from 'react';

interface GridPatternProps {
  opacity?: number;
  className?: string;
}

export const GridPattern: React.FC<GridPatternProps> = ({ 
  opacity = 0.25,
  className = '' 
}) => {
  return (
    <div 
      className={`absolute inset-0 -z-10 ${className}`}
      style={{
        backgroundImage: `
          linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
          linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)
        `,
        backgroundSize: '111.11px 111.11px',
        opacity
      }}
    />
  );
};