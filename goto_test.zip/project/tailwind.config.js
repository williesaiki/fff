/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'neon-green': '#C4FC33',
      },
      fontFamily: {
        'inter': ['Inter', 'sans-serif'],
        'eloquia': ['Eloquia Text', 'sans-serif'],
      },
      textShadow: {
        'neon': '0px 0px 23.3px rgba(196, 252, 51, 0.29)',
      },
    },
  },
  plugins: [
    function({ addUtilities }) {
      const newUtilities = {
        '.text-shadow-neon': {
          textShadow: '0px 0px 23.3px rgba(196, 252, 51, 0.29)',
        },
      }
      addUtilities(newUtilities)
    }
  ],
};