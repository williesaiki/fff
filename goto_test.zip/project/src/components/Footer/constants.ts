import { SocialLink } from './types';

export const SOCIAL_LINKS: SocialLink[] = [
  {
    icon: '/linkedin.svg',
    href: 'https://www.linkedin.com/company/flat-for-flip/',
    label: 'LinkedIn',
  },
  {
    icon: '/x.svg',
    href: 'https://x.com/FlatforFlipNFT',
    label: 'X (Twitter)',
  },
  {
    icon: '/lineicons_telegram.svg',
    href: 'https://t.me/flatforflip_community',
    label: 'Telegram',
  },
];
