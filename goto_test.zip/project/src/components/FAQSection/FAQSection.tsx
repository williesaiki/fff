import React from 'react';
import { motion } from 'framer-motion';
import { FAQAccordion } from './FAQAccordion';
import { FAQBackground } from './FAQBackground';
import { CityVector } from '../CityVector/CityVector';

export const FAQSection: React.FC = () => {
  return (
    <section className="py-16 px-4 relative min-h-screen" id="faq">
      <FAQBackground />
      <CityVector />
      <div className="max-w-7xl mx-auto relative">
        <div className="text-center">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="inline-flex justify-center items-center px-[15px] py-[5px] w-[130px] h-[34px] rounded-[12px] backdrop-blur-[7.3px]"
            style={{
              background: 'linear-gradient(0deg, rgba(0, 0, 0, 0.06), rgba(0, 0, 0, 0.06)), linear-gradient(224.83deg, rgba(255, 255, 255, 0.13) -7.89%, rgba(255, 255, 255, 0.04) 105.6%)'
            }}
          >
            <span className="font-inter font-normal text-[14px] leading-[17px] text-[#A2A2A2]">
              FAQ
            </span>
          </motion.div>
          
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="font-inter font-semibold text-[55px] leading-[67px] text-center text-white mb-4 mt-6"
          >
            Get to know us
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="font-['Eloquia_Text'] font-light text-[15px] leading-[17.82px] text-center text-[#9B9B9B] mb-[72px] px-4"
          >
            For a more in-depth understanding of $FFF please refer to the Whitepaper.
          </motion.p>

          <div className="w-full max-w-[709px] mx-auto px-4">
            <FAQAccordion />
          </div>
        </div>
      </div>
    </section>
  );
};