import React from 'react';
import { motion } from 'framer-motion';
import { floatingAnimation } from './animations';

interface SquareProps {
  className: string;
  size: number;
  rotate?: number;
  shadow?: boolean;
  hideOnMobile?: boolean;
  delay?: number;
}

export const Square: React.FC<SquareProps> = ({
  className,
  size,
  rotate: initialRotate = 0,
  shadow,
  hideOnMobile,
  delay = 0
}) => {
  const variants = floatingAnimation(6 + delay, 15, 3);

  return (
    <motion.div
      className={`fixed ${className} ${hideOnMobile ? 'hidden md:block' : ''}`}
      initial="initial"
      animate="animate"
      variants={variants}
      style={{ originX: 0.5, originY: 0.5 }}
    >
      <div
        className={`
          absolute bg-[#C4FC33] rounded-lg opacity-20 md:opacity-100
          ${shadow ? 'shadow-[0_0_56.5px_rgba(196,252,51,0.19)]' : ''}
          transition-all duration-300
        `}
        style={{
          width: size,
          height: size,
          transform: `rotate(${initialRotate}deg)`
        }}
      />
    </motion.div>
  );
};