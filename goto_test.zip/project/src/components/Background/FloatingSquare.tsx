import React from 'react';
import { motion } from 'framer-motion';
import { getRandomNumber } from './utils/random';

interface FloatingSquareProps {
  size?: number;
  delay?: number;
  x?: number;
  y?: number;
}

export const FloatingSquare: React.FC<FloatingSquareProps> = ({
  size = 80,
  delay = 0,
  x = 100,
  y = 100,
}) => {
  // Generate random movement parameters for more organic motion
  const duration = getRandomNumber(15, 25);
  const rotateStart = getRandomNumber(-180, 180);
  const rotateEnd = getRandomNumber(-180, 180);
  const scaleRange = [0.8, 1, 0.9];
  
  return (
    <motion.div
      className="absolute bg-neon-green/20 rounded-lg blur-xl"
      style={{ width: size, height: size }}
      animate={{
        x: [0, x * 0.5, -x * 0.3, x],
        y: [0, -y * 0.7, y * 0.4, 0],
        rotate: [rotateStart, rotateEnd],
        scale: scaleRange,
      }}
      transition={{
        duration,
        delay,
        repeat: Infinity,
        ease: "easeInOut",
        times: [0, 0.4, 0.7, 1]
      }}
    />
  );
};