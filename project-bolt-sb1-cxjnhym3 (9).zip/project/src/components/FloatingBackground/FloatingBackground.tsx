import React from 'react';
import { Square } from './Square';

const squares = [
  { size: 'lg', delay: 0, animationType: 'normal', className: 'top-[20%] left-[20%]' },
  { size: 'sm', delay: 1, animationType: 'delay', className: 'top-[70%] right-[25%]' },
  { size: 'md', delay: 2, animationType: 'slow', className: 'top-[40%] left-[35%]' },
  { size: 'lg', delay: 1.5, animationType: 'normal', className: 'bottom-[30%] right-[30%]' },
  { size: 'sm', delay: 2.5, animationType: 'delay', className: 'top-[25%] right-[40%]' },
  { size: 'md', delay: 0.5, animationType: 'slow', className: 'bottom-[40%] left-[45%]' },
  { size: 'lg', delay: 3, animationType: 'normal', className: 'top-[45%] right-[15%]' },
  { size: 'md', delay: 2, animationType: 'delay', className: 'bottom-[20%] left-[25%]' },
];

export const FloatingBackground: React.FC = () => {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {squares.map((square, index) => (
        <Square key={index} {...square} />
      ))}
    </div>
  );
};