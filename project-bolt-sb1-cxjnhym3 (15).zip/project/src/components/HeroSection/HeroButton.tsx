import React from 'react';
import { motion } from 'framer-motion';
import { LaunchAppButton } from '../Navbar/LaunchAppButton';

export const HeroButton: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.6 }}
      className="pt-8"
    >
      <LaunchAppButton className="bg-neon-green text-black px-8 py-3 rounded-lg font-semibold text-lg hover:bg-neon-green/90 transition-colors w-[245px]" />
    </motion.div>
  );
};