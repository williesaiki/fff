import React from 'react';
import { PartnersTitle } from './PartnersTitle';
import { PartnersGrid } from './PartnersGrid';

export const Partners: React.FC = () => {
  return (
    <section className="py-16">
      <div className="max-w-7xl mx-auto px-4">
        <PartnersTitle />
        <PartnersGrid />
      </div>
    </section>
  );
};