import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { LaunchAppButton } from './LaunchAppButton';

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const menuItems = [
  { href: '#about', label: 'About' },
  { href: '#team', label: 'Team' },
  { href: '#token', label: 'Token' },
  { href: '#roadmap', label: 'Roadmap' },
  { href: '#faq', label: 'FAQ' },
  { href: '#docs', label: 'Docs' },
  { href: '/docs/whitepaper_flat_for_flip.pdf', label: 'Whitepaper', isExternal: true },
  { href: '/docs/pitchdeck_flat_for_flip.pdf', label: 'Pitchdeck', isExternal: true },
  { href: '/docs/tokenomics_flat_for_flip.pdf', label: 'Tokenomics', isExternal: true }
];

export const MobileMenu: React.FC<MobileMenuProps> = ({ isOpen, onClose }) => {
  const navigate = useNavigate();

  const handleClick = (href: string, isExternal?: boolean) => {
    if (isExternal) {
      window.open(href, '_blank');
    } else if (href.startsWith('#')) {
      const element = document.querySelector(href);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="fixed inset-x-0 top-16 bg-black h-[calc(100vh-4rem)]"
        >
          <div className="flex flex-col items-center gap-8 px-4 py-8">
            <nav className="flex flex-col items-center gap-6 w-full">
              {menuItems.map(({ href, label, isExternal }) => (
                <button
                  key={href}
                  onClick={() => handleClick(href, isExternal)}
                  className="w-full text-center text-lg font-medium text-[#9B9B9B] hover:text-neon-green hover:text-shadow-neon transition-all"
                >
                  {label}
                </button>
              ))}
            </nav>

            <LaunchAppButton className="w-full max-w-[245px] h-[55px] bg-neon-green text-black font-bold text-lg rounded shadow-[0_0_122.4px_rgba(196,252,51,0.22)] hover:bg-neon-green/90 transition-colors" />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};