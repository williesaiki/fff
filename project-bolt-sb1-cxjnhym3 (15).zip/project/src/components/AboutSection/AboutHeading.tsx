import React from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';
import { useMediaQuery } from '@mui/material'; // Correct import for MUI

export const AboutHeading: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const isDesktop = useMediaQuery('(min-width: 1024px)'); // Check for desktop view

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start end', 'end start'],
  });

  const y = useTransform(scrollYProgress, [0, 1], [-170, 640]); // Zwiększony zakres transformacji

  return (
    <div
      ref={containerRef}
      className="flex flex-col items-center md:items-start gap-[10px] w-full md:w-[422px] sticky top-32"
    >
      {/* "About us" badge always visible */}
      <motion.div
        style={isDesktop ? { y } : {}}
        className="flex flex-row justify-center items-center px-[15px] py-[5px] w-[130px] h-[34px] rounded-[12px] backdrop-blur-[7.3px] bg-gradient-to-r from-[#0E0E0E] to-[#1B1B1B]"
      >
        <span className="w-[60px] h-[17px] font-inter font-normal text-[14px] leading-[17px] text-[#A2A2A2]">
          About us
        </span>
      </motion.div>

      <motion.div
        style={isDesktop ? { y } : {}}
        className="flex flex-col items-center md:items-start"
      >
        {/* "Real" text */}
        <span className="font-inter font-normal text-[40px] md:text-[55px] leading-[1.2] text-white">
          Real
        </span>

        {/* "ESTATE" with vertical line */}
        <div className="flex flex-row items-center">
          <span className="font-inter font-bold text-[72px] md:text-[100px] leading-[1.2] text-neon-green">
            ESTATE
          </span>
          <div className="hidden md:block w-1 h-[107px] bg-neon-green shadow-[0px_0px_38.7px_#C4FC33] ml-[11px]" />
        </div>

        {/* Description with same animation */}
        <p className="font-['Eloquia_Text'] font-light text-[15px] leading-[18px] text-[#9B9B9B] text-center md:text-left w-full md:w-[422px]">
          Revolutionizing real estate investment through blockchain technology
          and tokenization.
        </p>
      </motion.div>
    </div>
  );
};
