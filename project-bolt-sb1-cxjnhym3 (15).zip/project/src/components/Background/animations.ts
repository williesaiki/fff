import { Variants } from 'framer-motion';

export const floatingAnimation = (
  duration: number = 6,
  y: number = 10,
  rotate: number = 5
): Variants => ({
  initial: {
    y: 0,
    rotate: 0,
  },
  animate: {
    y: [-y, y, -y],
    rotate: [-rotate, rotate, -rotate],
    transition: {
      duration,
      repeat: Infinity,
      ease: "easeInOut"
    }
  }
});

export const pulseAnimation: Variants = {
  initial: { opacity: 0.6 },
  animate: {
    opacity: [0.6, 0.8, 0.6],
    transition: {
      duration: 4,
      repeat: Infinity,
      ease: "easeInOut"
    }
  }
};