import React from 'react';
import { motion } from 'framer-motion';

interface StaticSquareProps {
  size: number;
  rotation: number;
  opacity: number;
  top: string;
  left: string;
  delay?: number;
}

export const StaticSquare: React.FC<StaticSquareProps> = ({
  size,
  rotation,
  opacity,
  top,
  left,
  delay = 0
}) => {
  return (
    <motion.div
      className="absolute bg-neon-green rounded-lg blur-sm"
      style={{
        width: size,
        height: size,
        top,
        left,
        transform: `rotate(${rotation}deg)`,
        opacity
      }}
      initial={{ opacity: 0, scale: 0 }}
      animate={{ opacity, scale: 1 }}
      transition={{
        duration: 0.8,
        delay,
        ease: "easeOut"
      }}
    />
  );
};