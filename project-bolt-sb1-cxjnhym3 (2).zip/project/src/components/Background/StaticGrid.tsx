import React, { useMemo } from 'react';
import { StaticSquare } from './StaticSquare';
import { getRandomNumber, getRandomRotation, getRandomSize, getRandomOpacity } from './utils/random';

interface GridPosition {
  top: string;
  left: string;
  size: number;
  rotation: number;
  opacity: number;
}

const generatePositions = (count: number): GridPosition[] => {
  const positions: GridPosition[] = [];
  
  for (let i = 0; i < count; i++) {
    positions.push({
      top: `${getRandomNumber(5, 95)}%`,
      left: `${getRandomNumber(5, 95)}%`,
      size: getRandomSize(),
      rotation: getRandomRotation(),
      opacity: getRandomOpacity()
    });
  }
  
  return positions;
};

export const StaticGrid: React.FC = () => {
  const positions = useMemo(() => generatePositions(12), []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {positions.map((pos, index) => (
        <StaticSquare
          key={index}
          {...pos}
          delay={index * 0.1}
        />
      ))}
    </div>
  );
};