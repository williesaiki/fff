import React from 'react';
import { motion } from 'framer-motion';
import { LinksGrid } from './LinksGrid';
import { SocialLinks } from './SocialLinks';
import { Logo } from './Logo';
import { BackToTop } from '../BackToTop';

export const LinksSection: React.FC = () => {
  return (
    <section className="py-16 px-4 relative">
      <div className="max-w-7xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="inline-block px-4 py-2 rounded-full bg-white/5 text-sm mb-6"
        >
          DOCS
        </motion.div>
        
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          className="text-5xl font-bold mb-4"
        >
          Check our Links
        </motion.h2>
        
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="text-gray-400 max-w-2xl mx-auto mb-12"
        >
          For a more in-depth understanding of $FFF please refer to the Whitepaper.
        </motion.p>

        <LinksGrid />
        
        <div className="mt-24 space-y-8">
          <Logo />
          <BackToTop />
          <SocialLinks />
          <div className="text-gray-400">
            <p>FLATFORFLIP</p>
            <a href="mailto:contact@flatforflip.com" className="text-neon-green hover:text-neon-green/80 transition-colors">
              contact@flatforflip.com
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};