import React from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';

export const AboutHeading: React.FC = () => {
  const { scrollYProgress } = useScroll();
  const y = useTransform(scrollYProgress, [0, 1], [0, 100]);

  return (
    <div className="mb-4 md:mb-0 sticky top-24">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        style={{ y }}
        className="space-y-3 md:pl-24"
      >
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="px-4 py-2 rounded-full bg-white/5 text-sm mb-3 inline-block"
        >
          About us
        </motion.div>
        
        <h2 className="text-6xl font-bold">
          Real<br />
          <span className="text-neon-green">ESTATE</span>
        </h2>
        <p className="text-gray-400 max-w-md">
          Revolutionizing real estate investment through blockchain technology and tokenization.
        </p>
      </motion.div>
    </div>
  );
};