import React from 'react';
import { Menu, X } from 'lucide-react';
import { motion } from 'framer-motion';

interface MobileMenuButtonProps {
  isOpen: boolean;
  onClick: () => void;
}

export const MobileMenuButton: React.FC<MobileMenuButtonProps> = ({ isOpen, onClick }) => {
  return (
    <button 
      onClick={onClick}
      className="p-2"
      aria-label={isOpen ? 'Close menu' : 'Open menu'}
    >
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.2 }}
        className="text-white hover:text-neon-green"
      >
        {isOpen ? <X size={32} /> : <Menu size={32} />}
      </motion.div>
    </button>
  );
};