import React from 'react';
import { motion } from 'framer-motion';
import { TimelineItemType } from './types';

interface TimelineItemProps {
  item: TimelineItemType;
  index: number;
}

export const TimelineItem: React.FC<TimelineItemProps> = ({ item, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="relative"
    >
      <div className="flex items-center justify-center">
        {item.type === 'year' ? (
          <span className="text-neon-green font-bold text-xl">
            {item.content}
          </span>
        ) : (
          <div className="max-w-xl text-center">
            <p className="text-gray-400/90">{item.content}</p>
          </div>
        )}
      </div>
      
      {item.type !== 'year' && (
        <motion.div 
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
          initial={{ scale: 0 }}
          whileInView={{ scale: 1 }}
          transition={{ delay: index * 0.1 }}
        >
          <div className="w-2.5 h-2.5 rounded-full bg-neon-green shadow-lg shadow-neon-green/50" />
        </motion.div>
      )}
    </motion.div>
  );
};