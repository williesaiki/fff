import { SocialLink } from './types';

export const SOCIAL_LINKS: SocialLink[] = [
  {
    icon: '/linkedin.svg',
    href: 'https://linkedin.com/company/flatforflip',
    label: 'LinkedIn'
  },
  {
    icon: '/x.svg',
    href: 'https://x.com/flatforflip',
    label: 'X (Twitter)'
  },
  {
    icon: '/lineicons_telegram.svg',
    href: 'https://t.me/flatforflip',
    label: 'Telegram'
  },
  {
    icon: '/cbi_discord.svg',
    href: 'https://discord.gg/flatforflip',
    label: 'Discord'
  }
];