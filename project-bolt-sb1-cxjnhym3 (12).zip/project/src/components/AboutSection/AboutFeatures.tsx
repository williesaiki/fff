import React from 'react';
import { AboutFeature } from './AboutFeature';

const features = [
  {
    title: "Real estate-backed security",
    description: "We stand out by ensuring stability and value through real estate assets."
  },
  {
    title: "Tokenomics Strategy",
    description: "Our tokenomics focus on sustainable growth, encouraging users to participate in real estate projects while building the token's value."
  },
  {
    title: "Security and Auditing",
    description: "Every project undergoes legal, financial, and economic analysis before being presented to the community."
  },
  {
    title: "Innovation in Real Estate Market",
    description: "The ability to gain exposure to the real estate market regardless of your country of residence or the location of the property."
  }
];

export const AboutFeatures: React.FC = () => {
  return (
    <div className="flex flex-col items-center md:items-start gap-[40px] md:gap-[73px] w-full md:w-[541px]">
      {features.map((feature, index) => (
        <AboutFeature
          key={index}
          number={index + 1}
          title={feature.title}
          description={feature.description}
          isActive={false}
        />
      ))}
    </div>
  );
};