import React from 'react';
import { navLinks } from './navConfig';

export const NavLinks: React.FC = () => {
  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="flex justify-center items-center gap-[69px] mx-auto w-[657px] h-[22px]">
      {navLinks.map((link) => (
        <a
          key={link.href}
          href={link.href}
          onClick={(e) => scrollToSection(e, link.href)}
          className="font-inter font-medium text-[18px] leading-[22px] text-center text-[#9B9B9B] hover:text-neon-green hover:text-shadow-neon transition-colors"
          style={{
            width: link.label === 'About' ? '53px' :
                  link.label === 'Team' ? '48px' :
                  link.label === 'Token' ? '53px' :
                  link.label === 'Roadmap' ? '82px' :
                  link.label === 'FAQ' ? '32px' :
                  link.label === 'Docs' ? '44px' : undefined
          }}
        >
          {link.label}
        </a>
      ))}
    </div>
  );
};